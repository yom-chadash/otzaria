"""Verify the historical Windows ARM64 native correctness artifact."""
import argparse
import json
from pathlib import Path
import re

from analyze_followup_failures import read, sha, verify_zip


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    root = parser.parse_args().root.resolve()
    evidence = verify_zip(root)
    p = root / 'installed-plugin-probe'
    report_path = p / 'device/installed-plugin-report.json'
    report = read(report_path)
    architecture = read(p / 'pdf-architecture.json')
    source = 'cb8be0a523780785c088314cd25a6127633632ca'
    assert report['commit'] == architecture['commit'] == source
    assert report['status'] == architecture['status'] == 'passed'
    assert report['platform'] == 'windows' and report['buildMode'] == 'profile'
    assert report['flutterVersion'] == '3.47.7' and 'windows_arm64' in report['dartVersion']
    assert not report['errors'] and not report['contractErrors'] and not report['testFailures'] and report['frameworkPassed']
    host_reports = list((p / 'host').glob('*/report.json'))
    assert len(host_reports) == 1 and sha(host_reports[0]) == architecture['reportSha256']
    assert architecture['pid'] == report['pid'] and architecture['runId'] == report['runId']
    assert architecture['architecture'] == 'arm64'
    for item in [architecture['executable'], *architecture['modules']]:
        assert item['format'] == 'PE' and item['architecture'] == 'arm64' and item['machine'] == 0xAA64
    runtime = report['pdfRuntime']
    assert runtime['status'] == 'passed' and len(runtime['steps']) == 8
    assert all(step['status'] == 'passed' for step in runtime['steps'].values())
    steps = runtime['steps']
    assert {item['name']: (item['path'], item['sha256'], item['bytes']) for item in architecture['modules']} == {
        item['name']: (item['path'], item['sha256'], item['bytes']) for item in steps['loadedModules']['modules']}
    assert not steps['loadedModules']['unresolvedModuleHandles']
    cycles = steps['repeatedLifecycle']['cycles']
    assert steps['repeatedLifecycle']['completedCycles'] == steps['repeatedLifecycle']['requiredCycles'] == len(cycles) == 50
    assert [cycle['cycle'] for cycle in cycles] == list(range(1, 51))
    assert all(cycle['nativeCloseCompleted'] and cycle['ownedTabsRemaining'] == 0 and cycle['differentDocument']
        and cycle['targetCenterVisible'] and cycle['visibleRenderState'] == 'ready' and cycle['raster']['contentPixelsVerified'] for cycle in cycles)
    transitions = steps['desktopLifecycle']['actions']
    assert [item['name'] for item in transitions] == ['hide', 'minimize', 'resize', 'switchSecondary', 'switchPrimary', 'memoryPressure']
    assert all(item['status'] == 'passed' for item in transitions)
    assert steps['concurrentWork']['indexedPages'] == [0, 1, 2, 3]
    vector = steps['concurrentWork']['vectorExport']
    assert vector['textPreserved'] and vector['rightToLeft'] and vector['printingRasterVerified']
    assert runtime['ownedDocumentsRemaining'] == runtime['ownedTabsRemaining'] == 0 and not runtime['indexingActiveAfter']
    assert steps['teardown']['viewerNativeCloseCompleted'] and steps['teardown']['viewerLoadingCount'] == 0
    plugin_passes = sum(phase['status'] == 'passed' for phase in report['phases'])
    assert plugin_passes == 19
    contracts = (p / 'contract-tests.log').read_text()
    assert re.search(r'\+131 ~1: All tests passed!', contracts)
    assert 'Skip: Creating symlinks needs a separate Windows privilege.' in contracts
    assert 'No issues found!' in (p / 'analyze.log').read_text()
    exit_record = read(p / 'windows-native-exit.json')
    assert exit_record['status'] == 'passed' and exit_record['nativeExit']['processId'] == report['pid']
    assert exit_record['nativeExit']['runId'] == report['runId'] and exit_record['reportSha256'] == sha(report_path)
    lock = read(root / 'source-lock-receipt.json')
    assert lock['sourceCommit'] == source and lock['sha256'] == sha(root / lock['path'])
    assert all(item['description']['resolved-ref'] == 'cdea38083d06b445b4ec67d8345109a0457924af' for item in lock['packages'].values())
    summary = {'schemaVersion': 1, 'classification': 'completed-app-correctness', 'declaredScopeComplete': True,
        'runId': 45426169680, 'jobId': 138558664303, 'artifactId': 14937993368, 'sourceCommit': source,
        'jobUrl': 'https://github.com/yom-chadash/otzaria/actions/runs/45426169680/job/138558664303',
        **evidence, 'pdfrxCompatiblePin': 'cdea38083d06b445b4ec67d8345109a0457924af',
        'platform': 'windows', 'architecture': 'arm64', 'buildMode': 'profile', 'flutterVersion': '3.47.7',
        'dartVersion': report['dartVersion'], 'analyze': 'passed',
        'dartContracts': {'passed': 131, 'failed': 0, 'skipped': 1, 'skipReason': 'Creating symlinks needs a separate Windows privilege.'},
        'javascriptFixtureContracts': {'passed': 10, 'failed': 0, 'skipped': 0},
        'pluginPhasesPassed': plugin_passes, 'pdfPhasesPassed': 8, 'nativeWindowTransitionsPassed': len(transitions),
        'repeatedOpenCloseCycles': len(cycles), 'indexedPages': [0, 1, 2, 3], 'vectorExport': vector,
        'architectureReceipt': {'path': 'installed-plugin-probe/pdf-architecture.json', 'sha256': sha(p / 'pdf-architecture.json'),
            'appAndMappedPdfLibraries': 4, 'machine': '0xAA64', 'hostReportSha256Verified': True},
        'nativeExit': {'status': exit_record['status'], 'exitStatusHex': exit_record['nativeExit']['exitStatusHex'],
            'terminationCause': exit_record['nativeExit']['terminationCause']},
        'performanceMeasurement': False, 'physicalDeviceAcceptance': False, 'physicalPrinter': 'notRun',
        'multipleNativeWindows': 'notRun', 'physicalSleep': 'notRun',
        'limitations': ['This is the historical cb8be0a/cdea source, before the owner-tracker and 4f navigation fixes; it is not their final acceptance.',
            'The old fixture tracks initially captured owners; this successful run does not establish all replacement-owner lifecycle coverage.',
            'Native process exit 0xFFFFFFFF was observed; the driver can stop the app and the termination cause is not inferred.',
            'Functional counters and native file-header receipts are verified, not a latency improvement or physical-device/printer qualification.']}
    output = root / 'analysis-summary.json'
    payload = (json.dumps(summary, indent=2, ensure_ascii=False) + '\n').encode()
    if output.exists():
        assert output.read_bytes() == payload, 'Refusing to change a frozen summary'
    else:
        output.write_bytes(payload)
    print(json.dumps({'summary': str(output), 'sha256': sha(output), 'cycles': len(cycles), 'pdfPhases': 8, 'architecture': 'arm64'}))


if __name__ == '__main__':
    main()
