"""Post-download correctness summaries; never executes the application."""
import hashlib
import json
from pathlib import Path
import zipfile

BASE = Path('/workspace/scratch/8fd497e5cf89/pdf-5538-ci-evidence')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def single(root, name):
    paths = list(root.rglob(name))
    assert len(paths) == 1, (root, name, paths)
    return paths[0]


def start(root):
    receipt = read(root / 'artifact-receipt.json')
    archive = root / 'artifact.zip'
    assert digest(archive) == receipt['sha256']
    assert archive.stat().st_size == receipt['size']
    members = []
    with zipfile.ZipFile(archive) as bundle:
        for item in bundle.infolist():
            if item.is_dir():
                continue
            data = bundle.read(item)
            assert (root / item.filename).read_bytes() == data
            members.append({'path': item.filename, 'bytes': len(data),
                            'sha256': hashlib.sha256(data).hexdigest()})
    return {
        'schemaVersion': 1,
        'analysisKind': 'post-download correctness analysis; original artifact members are unchanged',
        'runId': receipt['run'], 'jobId': receipt['job'], 'artifactId': receipt['artifact'],
        'jobUrl': f"https://github.com/yom-chadash/otzaria/actions/runs/{receipt['run']}/job/{receipt['job']}",
        'sourceCommit': receipt['source'], 'artifactZipSha256': receipt['sha256'],
        'artifactZipBytes': receipt['size'], 'performanceComparison': False,
        'rawEvidence': members,
    }


def finish(root, summary):
    output = root / 'analysis-summary.json'
    assert not output.exists(), output
    output.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({'group': root.name, 'sha256': digest(output),
                      'classification': summary['classification']}))


for root in sorted(BASE.glob('pdf-multi-window-*')):
    if not root.is_dir():
        continue
    summary = start(root)
    verified = read(single(root, 'verified.json'))
    host = read(single(root, 'host.json'))
    assert verified['status'] == 'passed' and verified['exitCode'] == 0
    assert verified['sourceSha'] == host['sourceSha'] == summary['sourceCommit']
    assert host['flutter']['frameworkVersion'] == '3.47.7'
    assert verified['engineIdentity'] == host['engineIdentity']
    assert verified['bundleManifestSha256'] == host['bundleIdentity']['manifestSha256']
    assert verified['aotPayload'] == host['bundleIdentity']['aotPayload']
    states = host['source']
    assert states['beforeBuild'] == states['afterBuild'] == states['afterRun']
    assert states['beforeBuild']['clean'] is True
    summary.update(jobConclusion='success', platform=host['platform'], buildMode=host['buildMode'],
                   flutter=host['flutter'], sourceUnchanged=True,
                   engineRevision=host['engineRevision'], engineIdentity=verified['engineIdentity'],
                   bundleManifestSha256=verified['bundleManifestSha256'], aotPayload=verified['aotPayload'],
                   reportSha256=verified['reportSha256'], processExitCode=verified['exitCode'],
                   independentAppLaunches=1)
    reports = list(root.rglob('report.json'))
    if reports:
        assert len(reports) == 1
        report_path = reports[0]
        report = read(report_path)
        completion = read(single(root, 'completion.json'))
        assert digest(report_path) == completion['reportSha256'] == verified['reportSha256']
        assert completion['status'] == 'passed' and completion['error'] is None
        assert completion['unhandledErrors'] == []
        assert completion['sourceSha'] == summary['sourceCommit']
        assert completion['engineIdentity'] == verified['engineIdentity']
        assert completion['bindingClass'] == 'WidgetsFlutterBinding'
        assert completion['nativePlatformDispatcher'] is True
        assert report['status'] == 'passed' and report['realPlatformDispatcher'] is True
        expected = ['open', 'concurrentWork', 'minimizeRestore', 'closeSecondary', 'reopen', 'closeReopened', 'teardown']
        assert list(report['steps']) == expected
        assert all(step['status'] == 'passed' for step in report['steps'].values())
        opening = report['steps']['open']
        assert opening['primary']['viewId'] != opening['secondary']['viewId']
        assert opening['primary']['nativeHandle'] != opening['secondary']['nativeHandle']
        teardown = report['steps']['teardown']
        assert all(teardown[key] == 0 for key in ('ownedWindowsRemaining', 'ownedDocumentsRemaining', 'pendingOperations'))
        assert teardown['indexingActive'] is False
        summary.update(classification='completed-app-correctness', rawScenarioReportRetained=True,
                       passedSteps=expected, separateNativeWindowsVerified=True,
                       teardown=teardown, fixture=report['fixture'])
    else:
        assert host['platform'] == 'linux'
        summary.update(classification='completed-app-correctness-partial-artifact',
                       rawScenarioReportRetained=False,
                       hostVerifiedScenarioPassed=True,
                       missingArtifactMembers=['run/report.json', 'run/completion.json', 'app.log', 'build.log'],
                       postDownloadScenarioContractRevalidation=False)
    summary['limitations'] = [
        'Functional correctness, one owned process on this host; no frame-time, CPU, memory or performance improvement claim.',
        'The fixture has four generated vector pages; this is not the real-book paired measurement campaign.',
        'Overlapping submissions do not demonstrate native parallel execution; physical printer and physical sleep were not exercised.',
        'Visible readiness is based on the rendered layer tree, not a GPU presentation-time claim.',
    ]
    if not reports:
        summary['limitations'].append('The Linux upload used host-context runner.temp while the process used container RUNNER_TEMP. Only five top-level host/verification/mapping JSON files survived. The host verified the report during CI, but its contents cannot be independently revalidated from this artifact.')
    finish(root, summary)


for name in ('installed-plugin-linux-wpe-x64-profile', 'installed-plugin-linux-wpe-arm64-profile', 'apple-webview-macos-profile'):
    root = BASE / name
    summary = start(root)
    report_path = single(root, 'installed-plugin-report.json')
    report = read(report_path)
    assert report['status'] == 'passed' and report['frameworkPassed'] is True
    assert report['commit'] == summary['sourceCommit']
    assert all(report[key] == [] for key in ('errors', 'contractErrors', 'testFailures'))
    assert report['flutterVersion'] == '3.47.7'
    pdf = report['pdfRuntime']
    assert pdf['status'] == 'passed' and pdf['bundlePathsVerified'] is True
    assert pdf['ownedDocumentsRemaining'] == pdf['ownedTabsRemaining'] == 0
    assert pdf['indexingActiveAfter'] is False
    assert len(pdf['steps']) == 8 and all(x['status'] == 'passed' for x in pdf['steps'].values())
    cycles = pdf['steps']['repeatedLifecycle']
    assert cycles['requiredCycles'] == cycles['completedCycles'] == len(cycles['cycles']) == 50
    assert all(c['nativeCloseCompleted'] and c['ownedTabsRemaining'] == 0 and c['raster']['contentPixelsVerified'] for c in cycles['cycles'])
    wrapper_paths = list(root.glob('**/host/*/report.json'))
    assert len(wrapper_paths) == 1
    assert read(wrapper_paths[0])['installedPluginProbe'] == report
    summary.update(classification='completed-app-correctness', jobConclusion='success',
                   platform=report['platform'], buildMode=report['buildMode'],
                   flutterVersion=report['flutterVersion'], dartVersion=report['dartVersion'],
                   independentAppLaunches=1, pdfSteps=list(pdf['steps']),
                   completedOpenRenderCloseCycles=50, verifiedNativeCloses=50,
                   fixture=pdf['fixture'], reportSha256=digest(report_path),
                   hostReportSha256=digest(wrapper_paths[0]),
                   loadedModules=pdf['steps']['loadedModules'],
                   teardown={key: pdf[key] for key in ('ownedDocumentsRemaining', 'ownedTabsRemaining', 'indexingActiveAfter')})
    architecture_paths = list(root.glob('pdf-architecture.json'))
    if architecture_paths:
        architecture = read(architecture_paths[0])
        assert architecture['status'] == 'passed' and architecture['commit'] == summary['sourceCommit']
        assert architecture['reportSha256'] == digest(wrapper_paths[0])
        summary['verifiedArchitecture'] = architecture['architecture']
        summary['nativeModules'] = architecture['modules']
    summary['limitations'] = [
        'This preserves general WebView/installed-app QA and PDF functional checks after benchmark cleanup; recorded phase timings are not an A/B performance study.',
        'Fifty reopen cycles occur inside one process and are not fifty independent launches.',
        'Four generated PDF pages only; no physical printer or physical sleep and no physical mobile-device acceptance.',
        'The installed-app desktopLifecycle scenario uses tabs; two actual OS windows are covered by the separate multi-window artifact.',
    ]
    finish(root, summary)


for platform in ('Linux', 'Windows'):
    root = BASE / ('pdf-5538-product-validation-' + platform)
    summary = start(root)
    assert (root / 'pdf-product-source.txt').read_text().strip() == summary['sourceCommit']
    summary['flutter'] = read(root / 'pdf-product-sdk.json')
    summary['platform'] = platform
    if platform == 'Linux':
        report_path = root / 'pdf-product-tests.json'
        events = [json.loads(line) for line in report_path.read_text().splitlines() if line.strip()]
        tests = [e for e in events if e['type'] == 'testDone' and not e.get('hidden', False)]
        assert len(tests) == 93 and all(t['result'] == 'success' and not t['skipped'] for t in tests)
        assert [e for e in events if e['type'] == 'done'] == [events[-1]] and events[-1]['success'] is True
        assert not [e for e in events if e['type'] == 'error']
        assert 'No issues found!' in (root / 'pdf-product-analyze.log').read_text()
        summary.update(classification='completed-product-regression-checks', jobConclusion='success',
                       fullFlutterAnalyze='passed', testsPassed=93, testsFailed=0, testsSkipped=0,
                       hiddenFixtureLifecycleEvents=sum(e['type'] == 'testDone' and e.get('hidden', False) for e in events),
                       jsonlRows=len(events), testReportFormat='JSON Lines in a .json-named file',
                       suites=[e['suite']['path'] for e in events if e['type'] == 'suite'])
    else:
        assert not (root / 'pdf-product-tests.json').exists()
        assert not (root / 'pdf-product-analyze.log').exists()
        summary.update(classification='blocked-before-product-checks', jobConclusion='failure',
                       failedJobStep='Resolve the exact committed dependencies',
                       fullFlutterAnalyze='notRun', testReportPresent=False,
                       cause='The retained artifact contains source and SDK receipts only; the job metadata identifies dependency resolution as the failing step. No further cause is inferred from absent logs.')
    summary['limitations'] = ['Product regression correctness, not a benchmark or proof of performance improvement.',
                              'The result applies only to the recorded commit, SDK and platform.']
    finish(root, summary)
