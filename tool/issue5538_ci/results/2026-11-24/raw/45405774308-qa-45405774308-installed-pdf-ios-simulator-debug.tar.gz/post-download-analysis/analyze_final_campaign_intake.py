"""Revalidate preserved partial campaigns and Apple correctness evidence."""

import json
from pathlib import Path
import re
import sys

from analyze_post_implementation import read, sha, start


def only(root, name):
    paths = list(root.rglob(name))
    assert len(paths) == 1, (root, name, paths)
    return paths[0]


def reader_partial(root, summary):
    campaign_path = only(root, "campaign.json")
    directory = campaign_path.parent
    campaign = read(campaign_path)
    assert campaign["status"] == "running"
    assert campaign["workflow"]["GITHUB_SHA"] == summary["sourceCommit"]
    assert campaign["workflow"]["GITHUB_RUN_ID"] == str(summary["runId"])
    assert campaign["sdk"]["frameworkVersion"] == "3.47.7"
    plan = campaign["plan"]
    conditions, reports, processes, viewports = [], [], [], set()
    blocks = 0
    for condition in campaign["conditions"]:
        done = [block for block in condition["blocks"] if block["status"] == "passed"]
        if condition["status"] == "passed":
            assert len(done) == 2
        conditions.append({"id": condition["id"], "status": condition["status"],
                           "completedPairedBlocks": len(done)})
        for block in done:
            blocks += 1
            relative = Path(block["results"].replace("\\", "/"))
            assert not relative.is_absolute() and ".." not in relative.parts
            for role in ("baseline", "candidate"):
                location = directory / relative / role
                report_path = location / "report.json"
                report = read(report_path)
                metadata = report["metadata"]
                assert report["complete"] is True and report["successful"] is True
                assert metadata["commit"] == campaign["sources"][role]["commit"]
                assert metadata["status"] == "passed" and metadata["dirty"] is False
                assert metadata["launchCount"] == plan["launchesPerBlock"]
                assert all(not state["statusPorcelain"] for state in metadata["sourceProvenance"].values())
                reports.append({"path": report_path.relative_to(root).as_posix(), "sha256": sha(report_path),
                                "condition": condition["id"], "role": role,
                                "commit": metadata["commit"], "viewport": metadata["viewport"]})
                for index in range(plan["launchesPerBlock"]):
                    launch = location / f"launch-{index:03d}"
                    completion = read(launch / "completion.json")
                    assert completion["status"] == "passed" and completion["error"] is None
                    assert completion["preparationOnly"] is False and completion["testFailures"] == []
                    assert completion["bindingClass"] == "WidgetsFlutterBinding"
                    assert completion["platformDispatcher"] == "native"
                    rows = [json.loads(line) for line in (launch / "phases.jsonl").read_text(encoding="utf-8-sig").splitlines() if line.strip()]
                    meta = [row for row in rows if row.get("type") == "meta" and "viewport" in row]
                    assert len(meta) == 1 and meta[0]["viewport"] == metadata["viewport"]
                    assert not [row for row in rows if row.get("type") == "phase" and row.get("status") == "failed"]
                    viewports.add(json.dumps(meta[0]["viewport"], sort_keys=True))
                    processes.append({"path": launch.relative_to(root).as_posix(), "condition": condition["id"],
                                      "role": role, "completionSha256": sha(launch / "completion.json"),
                                      "phasesSha256": sha(launch / "phases.jsonl")})
    assert len(viewports) <= 1, "Incomparable geometry among completed blocks"
    completed = [condition["id"] for condition in campaign["conditions"] if condition["status"] == "passed"]
    summary.update(classification="partial-campaign-cancelled", declaredScopeComplete=False,
                   jobConclusion="cancelled", lastProducerStatus=campaign["status"],
                   performanceImprovementClaim=False, wholeCampaignIntegrityClaim=False,
                   mode=campaign["mode"], platform=campaign["platform"], sdk=campaign["sdk"],
                   sourcePair=campaign["sources"], campaignSha256=sha(campaign_path),
                   plannedConditions=len(plan["cases"]) * len(plan["cacheStates"]) * len(plan["scenarios"]),
                   completedConditionCount=len(completed), completedConditions=completed,
                   attemptedConditions=conditions, completedPairedBlocks=blocks,
                   completedBlockProcessLaunches=len(processes), repetitionsWithinEachProcess=plan["repetitions"],
                   retainedGeometry=[json.loads(value) for value in sorted(viewports)],
                   completedBlockReports=reports, completedBlockProcesses=processes,
                   allRetainedReportFiles=sum(1 for _ in root.rglob("report.json")))
    summary["limitations"] = [
        "The workflow was cancelled while its producer still reported running; no whole-campaign success or final integrity guard is claimed.",
        "Counts use each canonical completed condition/block directory once; duplicated working-result files and preparation passes are not independent launches.",
        "Complete reports and per-process correctness were rechecked for completed paired blocks, including source cleanliness and identical viewport metadata.",
        "This preservation summary derives no performance improvement from partial coverage and does not attribute cancellation to product behavior.",
        "Repetitions within a process are correlated; cold means fresh application data, not a flushed OS file cache.",
    ]


def ios_large(root, summary):
    producer = read(root / "summary.json")
    assert producer["status"] == "passed"
    assert producer["source"]["commit"] == producer["largeSource"]["commit"] == summary["sourceCommit"]
    for source in (producer["source"], producer["largeSource"]):
        assert source["filesBefore"] == source["filesAfter"]
    assert producer["flutter"]["frameworkVersion"] == "3.47.7"
    for path, digest in producer["rawHashes"].items():
        assert sha(root / path) == digest
    command = read(root / "tests.command.json")
    assert command["exitCode"] == 0 and command["timedOut"] is False
    log = (root / "tests.log").read_text()
    for suite, names in producer["testNames"].items():
        passed = re.findall(r"Test Case '-\[" + re.escape(suite) + r"\." + re.escape(suite) + r" (\w+)\]' passed", log)
        assert sorted(passed) == sorted(names)
    assert producer["nativeContractTests"] == 22 and producer["realFilesUITests"] == 2
    assert read(root / "cleanup.json")["ownedSimulatorDeleted"] is True
    results = {}
    for case, expected in (("files-save", "saved"), ("files-cancel", "cancelled")):
        result = read(root / "probe" / f"{case}.json")
        assert result == producer["filesReceipts"][case]
        assert result["passed"] is True and result["outcome"]["status"] == expected
        assert result["destinationVerified"] is True and result["stagingAbsent"] is True
        assert result["backend"] == "MobilePdfExportService.instance"
        composition = result["composition"]
        assert composition["sourceSha256"] == producer["largeInput"]["sha256"]
        assert composition["sourceBytes"] == producer["largeInput"]["bytes"]
        assert composition["sourcePages"] == 374 and composition["sheetCount"] == 94
        assert composition["rows"] == composition["cols"] == 2
        if expected == "saved":
            assert result["expectedSha256"] == result["actualSha256"]
        else:
            assert result["actualSha256"] is None and result["outcome"]["documentUri"] is None
        results[case] = {"status": expected, "destinationVerified": True, "stagingAbsent": True,
                         "outputBytes": result["fixtureBytes"], "composition": composition,
                         "expectedSha256": result["expectedSha256"], "actualSha256": result["actualSha256"]}
    summary.update(classification="completed-app-correctness", declaredScopeComplete=True,
                   jobConclusion="success", platform="ios", environment="Intel-hosted iOS Simulator 26.2",
                   flutter=producer["flutter"], physicalDeviceAcceptance=False,
                   nativeContractTestsPassed=22, realFilesUiTestsPassed=2, testNames=producer["testNames"],
                   realPdfInput={key: producer["largeInput"][key] for key in ("sha256", "bytes", "fixture")},
                   sourceFilesUnchanged=True, filesResults=results, ownedSimulatorDeleted=True,
                   performanceComparison=False)
    summary["limitations"] = [
        "Real UIKit Files save/cancel with a 374-page scanned input, 94 composed sheets; local Simulator Files provider only.",
        "Composition times are recorded diagnostics of two UI cases, not a paired speedup study, a physical-device latency claim, or an independent memory study.",
        "Third-party providers, physical devices and physical printing were not exercised.",
    ]


def ios_cleanup(root, summary):
    verified = read(root / "verified-result.json")
    report_path = root / "device-output/installed-pdf-ios-report.json"
    report = read(report_path)
    wrapper_path = only(root / "host", "report.json")
    wrapper = read(wrapper_path)["installedPdfIosProbe"]
    assert all(report[key] == value for key, value in wrapper.items())
    assert verified["status"] == report["status"] == "passed"
    assert verified["commit"] == report["commit"] == summary["sourceCommit"]
    assert verified["runId"] == report["runId"]
    assert report["frameworkPassed"] is True and report["appUnmounted"] is True
    assert all(report[key] == [] for key in ("errors", "contractErrors", "testFailures"))
    assert report["flutterVersion"] == "3.47.7" and report["buildMode"] == "debug"
    assert verified["physicalDeviceAcceptance"] is False and verified["abiEvidence"]["abi"] == "ios_x64"
    simulator = read(root / "simulator.json")
    assert simulator == verified["simulator"] and simulator["flutterExitCode"] == 0
    assert simulator["cleanup"] == "deletedOwnedSimulator"
    pdf = report["pdfRuntime"]
    assert pdf["status"] == "passed" and pdf["bundlePathsVerified"] is True
    assert pdf["ownedDocumentsRemaining"] == pdf["ownedTabsRemaining"] == 0
    assert pdf["indexingActiveAfter"] is False
    assert len(pdf["steps"]) == 6 and all(step["status"] == "passed" for step in pdf["steps"].values())
    assert pdf["steps"]["teardown"]["viewerDetached"] is True
    assert pdf["steps"]["teardown"]["viewerNativeCloseCompleted"] is True
    for png in verified["pngArtifacts"]:
        path = root / "device-output" / Path(png["path"]).name
        assert path.stat().st_size == png["bytes"] and sha(path) == png["sha256"]
    summary.update(classification="completed-app-correctness", declaredScopeComplete=True,
                   jobConclusion="success", platform="ios", buildMode="debug", flutterVersion="3.47.7",
                   reportSha256=sha(report_path), wrapperReportSha256=sha(wrapper_path),
                   independentAppLaunches=1, passedPdfSteps=list(pdf["steps"]),
                   fixture=pdf["fixture"], bundledFiles=verified["bundledFiles"],
                   abiEvidence=verified["abiEvidence"], simulator=simulator,
                   teardown={key: pdf[key] for key in ("ownedDocumentsRemaining", "ownedTabsRemaining", "indexingActiveAfter")},
                   rawRasterHashesVerified=True, physicalDeviceAcceptance=False, performanceComparison=False)
    summary["limitations"] = [
        "Installed-app correctness on an owned Intel iOS Simulator in debug mode; no physical-device or performance acceptance.",
        "The fixture is generated; no physical printer and no WebView scenario ran in this iOS-specific job.",
        "Viewer, concurrent work, cancellation/recovery, reopen, loaded modules and teardown passed in one app process.",
    ]


if __name__ == "__main__":
    mode, *directories = sys.argv[1:]
    for name in directories:
        root = Path(name).resolve()
        summary = start(root)
        {"reader": reader_partial, "ios-large": ios_large, "ios-cleanup": ios_cleanup}[mode](root, summary)
        output = root / "analysis-summary.json"
        assert not output.exists(), output
        output.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
        print(json.dumps({"group": root.name, "classification": summary["classification"], "sha256": sha(output),
                          "completedConditions": summary.get("completedConditionCount")}))
