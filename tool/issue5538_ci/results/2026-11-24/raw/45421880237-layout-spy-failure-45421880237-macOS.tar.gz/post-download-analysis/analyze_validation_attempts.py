"""Preserve failed CI attempts and verify their original artifacts independently."""

import hashlib
import json
from pathlib import Path
import sys

from PIL import Image

from analyze_post_implementation import read, sha, start


LOG_IDENTITIES = {'navigation-before-launch-45420209174': {'sizeBytes': 70002, 'sha256': '1c9d2d4529d8cdca65f9a7f677dce9b67438b7ee5046932318ed0fc35ca286aa', 'normalization': 'LF', 'origin': 'GitHub connector decoded job log', 'originalActionsLogZip': False}, 'reader-bootstrap-45419791368-windows-profile': {'sizeBytes': 68360, 'sha256': '777ddb6dcc3d971486b251c926ef973b4c763c9b2a9d02aa2e81986ac4ddc915', 'normalization': 'LF', 'origin': 'GitHub connector decoded job log', 'originalActionsLogZip': False}, 'pdf-5538-font-profile-attempt3': {'sizeBytes': 513387, 'sha256': '9b4e740262f079e2786b2391194269f82460caa715d17a9692cfb1b8901a9bf3', 'normalization': 'none; connector text already LF', 'origin': 'GitHub connector decoded job log', 'originalActionsLogZip': False}, 'reuse-harness-mismatch-45415519185-linux-profile': {'sizeBytes': 500902, 'sha256': '8b6fd2bbfdc925edb8adb9c60d58433a80627e3efb99ce41fed7fb53b5d9c921', 'normalization': 'none; connector text already LF', 'origin': 'GitHub connector decoded job log', 'originalActionsLogZip': False}, 'reuse-harness-mismatch-45415519185-linux-release': {'sizeBytes': 500794, 'sha256': '2ae6516cb8fdf638511121327b0fef11aa10958419e668d774b540910f0eaef0', 'normalization': 'none; connector text already LF', 'origin': 'GitHub connector decoded job log', 'originalActionsLogZip': False}}


def decoded_log(root, summary):
    path = root / "workflow-job.log"
    if not path.is_file():
        return ""
    receipt = LOG_IDENTITIES[root.name]
    assert sha(path) == receipt["sha256"] and path.stat().st_size == receipt["sizeBytes"]
    summary["jobLog"] = {key: receipt[key] for key in (
        "sizeBytes", "sha256", "normalization", "origin", "originalActionsLogZip")}
    summary["jobLogSha256"] = receipt["sha256"]
    return path.read_text()


def blocked(root, summary):
    log = decoded_log(root, summary)
    summary.update(classification="blocked-before-measurement", jobConclusion="failure",
                   declaredScopeComplete=False, retainedIndependentMeasurements=0,
                   productPerformanceClaim=False, productRegressionEstablished=False)
    if root.name.startswith("reuse-harness-mismatch-"):
        error = "The orchestrator must use the same verified harness as the measured sources."
        assert error in log and not list(root.rglob("campaign.json"))
        summary.update(failureStage="orchestrator/source harness identity guard",
                       observedError=error, measuredProcessLaunches=0,
                       originalArtifactScope="Only four display/session setup files; the decoded job log records the guard failure.")
    elif root.name.startswith("navigation-before-launch-"):
        report = read(root / "diagnostic-summary.json")
        assert report["status"] == "diagnostic-infrastructure-failure" and report["attempts"] == []
        assert "JSONDecodeError" in report["error"] and "sdk_identity" in log
        summary.update(failureStage="strict Flutter SDK JSON parsing before native launch",
                       observedError=report["error"], measuredProcessLaunches=0,
                       diagnosticAttempts=0, diagnosticSourceCommit=report["sourceCommit"],
                       diagnosticSourceTree=report["sourceTree"],
                       explanation="The first Flutter invocation can bootstrap its tool and print non-JSON output; no trace was collected.")
    elif root.name.startswith("reader-bootstrap-"):
        report = read(root / "campaign.json")
        assert report["status"] == "failed" and report["conditions"] == [] and report["frozenBuilds"] == {}
        assert "JSONDecodeError" in report["error"] and "sdk_identity" in log
        summary.update(failureStage="strict Flutter SDK JSON parsing before native build/launch",
                       observedError=report["error"], measuredProcessLaunches=0,
                       completedConditions=0, plannedCases=report["plan"]["cases"],
                       sources={key: value["commit"] for key, value in report["sources"].items()},
                       explanation="Explicit SDK bootstrap was absent before strict JSON parsing; no reader measurements resulted.")
    else:
        raise ValueError(root)
    summary["limitations"] = [
        "Failure before measurements is retained as evidence, not converted to a passing or completed experiment.",
        "Decoded connector logs are separate from byte-verified original artifact ZIP members.",
    ]


def s02_attempt(root, summary):
    decoded_log(root, summary)
    base = root / "pdf-5538-font-profile"
    campaign = read(base / "report.json")
    assert campaign["status"] == "failed" and len(campaign["rows"]) == 2
    assert all(row["warmup"] is True for row in campaign["rows"])
    assert "wrong-document reports" in campaign["error"]
    variants, frames = [], []
    for folder in sorted((base / "initial-hebrew").iterdir()):
        config = read(folder / "config.json")
        report = read(folder / "result.json")
        sidecar = read(folder / "frame-receipts.json")
        assert report["status"] == "completed" and report["allNativeCloseFuturesCompleted"] is True
        assert not report["frameworkErrors"] and not report["frameCaptureErrors"]
        assert sidecar["measured"] == report["measuredFrames"]
        for row in sidecar["measured"] + sidecar["reference"]:
            path = folder / row["pngPath"]
            assert sha(path) == row["pngSha256"]
            with Image.open(path) as image:
                rgba = image.convert("RGBA")
                assert rgba.size == (row["width"], row["height"])
                assert hashlib.sha256(rgba.tobytes()).hexdigest() == row["rgbaSha256"]
            frames.append({"path": str(path.relative_to(root)), "sha256": sha(path),
                           "inputId": row["inputId"], "phase": row["phase"],
                           "renderState": row["renderState"], "stableDocument": row["stableDocument"]})
        actual = report["finalProofs"]["source-0"]
        reference = report["referenceProofs"]["source-0"]
        parity = report["parity"]["source-0"]
        assert all(parity[key] is True for key in (
            "textEqual", "geometryEqual", "fullPageRasterEqual", "stableMeasuredDocument"))
        assert actual["text"] == reference["text"] and "שלו ם" in reference["text"]
        assert not parity["referenceContainsExpectedWord"] and parity["firstGoodSampleUs"] is None
        assert parity["samples"] == 0
        extra = []
        opens = {event["documentId"]: event for event in report["measuredEvents"] if event["type"] == "nativeOpen"}
        inputs = {item["absolutePath"]: item for item in config["documents"]}
        for event in report["measuredEvents"]:
            if event["type"] != "missingFonts":
                continue
            assert event["eventOwnsDocument"] is True
            source = inputs[opens[event["documentId"]]["path"]]
            for query in event["queries"]:
                if query["face"] != source["requestedFace"]:
                    extra.append({"documentId": event["documentId"], "inputId": source["id"],
                                  "query": query, "eventOwnsDocument": True, "byPage": event["byPage"]})
        variants.append({"variant": report["variant"], "sourceCommit": report["sourceCommit"],
                         "appSourcesSha256": report["appSourcesSha256"],
                         "hostValidated": (folder / "validated.json").exists(),
                         "frameworkErrors": [], "frameCaptureErrors": [],
                         "sourceText": actual["text"], "sourceTextSha256": actual["textSha256"],
                         "nativeTextGeometryAndRasterEqualToFreshReference": True,
                         "literalExpectedWordPresent": False, "stableSourceFrameSamples": 0,
                         "sourceFirstGoodSampleUs": None, "extraQueriesBeyondSingleFaceFixture": extra,
                         "reportPath": str((folder / "result.json").relative_to(root))})
    assert [v["variant"] for v in variants] == ["A", "B", "C"] and len(frames) == 12
    assert [v["hostValidated"] for v in variants] == [True, True, False]
    assert not variants[0]["extraQueriesBeyondSingleFaceFixture"] and not variants[1]["extraQueriesBeyondSingleFaceFixture"]
    extra = variants[2]["extraQueriesBeyondSingleFaceFixture"]
    assert len(extra) == 1 and extra[0]["query"]["face"] == "Helvetica" and extra[0]["inputId"] == "source-0"
    fixture = base / "fixtures/initial-hebrew/source-0.pdf"
    assert b"/Helvetica" not in fixture.read_bytes()
    summary.update(classification="failed-warmup-fixture-and-frame-validation", jobConclusion="failure",
                   declaredScopeComplete=False, warmupProcessesExecuted=3, hostValidatedWarmupProcesses=2,
                   retainedIndependentMeasurements=0, completePairedBlocks=0, productPerformanceClaim=False,
                   observedError=campaign["error"], variants=variants, verifiedFramePngCount=len(frames), frames=frames,
                   oldHelveticaNativeOriginEstablished=False, crossDocumentLeakEstablished=False)
    summary["limitations"] = [
        "Three warmups ran; candidate validation rejected the third. No retained timing comparison exists.",
        "The old single-face resource validator rejects Helvetica; the event owns the correct document/page, but its native fallback origin was not established.",
        "Both actual and fresh-reference native extraction contain an artificial space before the final Hebrew letter; their parity does not satisfy the literal-word oracle.",
        "No stable target-page frame was captured for source-0. First-good latency cannot be reconstructed from the later reference image.",
        "The twelve original PNGs and failed raw reports are preserved unchanged; revised fixtures constitute a new experiment.",
    ]


def suite(path):
    events = [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    names = {row["test"]["id"]: row["test"]["name"] for row in events if row.get("type") == "testStart"}
    done = [row for row in events if row.get("type") == "testDone" and not row.get("hidden")]
    assert events[-1]["type"] == "done"
    return {"passed": sum(row["result"] == "success" and not row.get("skipped") for row in done),
            "failed": sum(row["result"] != "success" for row in done),
            "skipped": sum(bool(row.get("skipped")) for row in done),
            "failedTests": [names[row["testID"]] for row in done if row["result"] != "success"],
            "reporterSuccess": events[-1]["success"], "eventRows": len(events)}


def layout_spy(root, summary):
    source = (root / "pdf-layout-engine-source.txt").read_text(encoding="utf-8-sig").strip()
    assert source == "c0107a62ba1860c0803818dd642692b1b67e3b02"
    sdk = read(root / "pdf-layout-engine-sdk.json")
    assert sdk["frameworkVersion"] == "3.47.7" and sdk["dartSdkVersion"].startswith("3.13.5")
    assert "No issues found!" in (root / "pdf-layout-engine-analyze.log").read_text(encoding="utf-8-sig")
    engine = suite(root / "pdf-layout-engine-tests.jsonl")
    viewer = suite(root / "pdf-layout-engine-viewer-tests.jsonl")
    assert (engine["passed"], engine["failed"], engine["skipped"], engine["reporterSuccess"]) == (118, 0, 0, True)
    assert (viewer["passed"], viewer["failed"], viewer["skipped"], viewer["reporterSuccess"]) == (111, 1, 0, False)
    assert viewer["failedTests"] == ["font manager preparation is deferred until missing fonts are reported"]
    log = (root / "pdf-layout-engine-viewer-tests.log").read_text(encoding="utf-8-sig")
    assert "The PDF backend changed while preparing fonts. Retry the font load." in log
    summary.update(classification="failed-viewer-test-spy", declaredScopeComplete=False,
                   jobConclusion="failure", testedSourceCommit=source, platform=root.name.rsplit("-", 1)[-1],
                   staticAnalysis="passed", sdk=sdk, engineTests=engine, viewerTests=viewer,
                   performanceMeasurement=False, productPerformanceClaim=False)
    summary["limitations"] = [
        "The entire job failed even though analyze and all 118 engine tests passed.",
        "The failing test spy counts prepare calls but skips super.prepare, leaving the prepared backend unset; no real application prepare override was found.",
        "A separate test-only fix delegates preparation and awaits the complete load; its subsequent CI outcome is not inferred here.",
    ]


def main():
    for raw in sys.argv[1:]:
        root = Path(raw).resolve()
        summary = start(root)
        if root.name.startswith("layout-spy-failure-"):
            layout_spy(root, summary)
        elif root.name == "pdf-5538-font-profile-attempt3":
            s02_attempt(root, summary)
        else:
            blocked(root, summary)
        target = root / "analysis-summary.json"
        assert not target.exists(), "Refusing to replace a frozen analysis annotation"
        target.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
        print(json.dumps({"folder": root.name, "classification": summary["classification"],
                          "summarySha256": sha(target), "originalMembersVerified": summary["verifiedOriginalMembers"]}))


if __name__ == "__main__":
    main()
