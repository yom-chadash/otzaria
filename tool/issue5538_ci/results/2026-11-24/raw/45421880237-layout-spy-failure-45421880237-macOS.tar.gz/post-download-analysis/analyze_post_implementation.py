"""Recheck downloaded 5538 evidence without rerunning or changing original data."""

from collections import defaultdict
import hashlib
import json
from pathlib import Path
import statistics
import sys
import zipfile


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def start(root):
    receipt = read(root / "artifact-receipt.json")
    archive = root / "artifact.zip"
    assert sha(archive) == receipt["sha256"] and archive.stat().st_size == receipt["size"]
    with zipfile.ZipFile(archive) as source:
        files = [item for item in source.infolist() if not item.is_dir()]
        for item in files:
            assert (root / item.filename).read_bytes() == source.read(item)
    run, job = receipt.get("run", receipt.get("runId")), receipt.get("job", receipt.get("jobId"))
    return {"schemaVersion": 1, "analysisKind": "independent post-download verification; original members unchanged",
            "runId": run, "jobId": job, "artifactId": receipt.get("artifact", receipt.get("artifactId")),
            "sourceCommit": receipt.get("source"), "artifactZipSha256": receipt["sha256"],
            "artifactZipBytes": receipt["size"], "verifiedOriginalMembers": len(files),
            "jobUrl": f"https://github.com/yom-chadash/otzaria/actions/runs/{run}/job/{job}"}


def test_counts(path, *, allow_hook_diagnostics=False):
    events, diagnostics = [], []
    for number, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
        if not line.strip():
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            assert allow_hook_diagnostics and line.startswith("Running build hooks..."), (path, number)
            diagnostics.append({"line": number, "raw": line})
    tests = [event for event in events if event.get("type") == "testDone" and not event.get("hidden")]
    assert tests and not [event for event in events if event.get("type") == "error"]
    assert all(event["result"] == "success" and not event.get("skipped") for event in tests)
    assert [event for event in events if event.get("type") == "done"] == [events[-1]]
    assert events[-1]["success"] is True
    return {"passed": len(tests), "failed": 0, "skipped": 0, "eventRows": len(events),
            "hiddenLifecycleEvents": sum(event.get("type") == "testDone" and bool(event.get("hidden")) for event in events),
            "nonJsonBuildHookDiagnosticsPreserved": diagnostics}


def s02(root, summary):
    engine = "font-engine" in root.name
    prefix = "pdf-font-engine" if engine else "pdf-font"
    source = (root / f"{prefix}-source.txt").read_text(encoding="utf-8-sig").strip()
    sdk = read(root / f"{prefix}-sdk.json")
    assert sdk["frameworkVersion"] == "3.47.7" and sdk["dartSdkVersion"].startswith("3.13.5")
    assert "No issues found!" in (root / f"{prefix}-analyze.log").read_text(encoding="utf-8-sig")
    tests = test_counts(root / f"{prefix}-tests.{'jsonl' if engine else 'json'}")
    expected = 118 if engine else (29 if summary["runId"] == 45410596262 else 28)
    assert tests["passed"] == expected
    if engine:
        assert source == "964b5e15e082c8633651ffab1d037631af65e156"
    else:
        assert source == summary["sourceCommit"]
    complete = engine or summary["runId"] == 45410596262
    summary.update(classification="completed-product-regression-checks" if complete else "partial-product-checks-failed-job",
                   declaredScopeComplete=complete, jobConclusion="success" if complete else "failure",
                   testedSourceCommit=source, scope="S02 engine backport" if engine else "S02 app integration",
                   platform=root.name.rsplit("-", 1)[-1], sdk=sdk, tests=tests, staticAnalysis="passed",
                   performanceMeasurement=False, appFirstGoodFrameMeasured=False)
    summary["limitations"] = [
        "These are correctness regressions on the exact tested source, not latency or first-good-frame measurements.",
        "Engine source and fork workflow source are different commits and are recorded separately.",
    ]
    if not complete:
        summary["limitations"].append("The first app job failed after producing passing analyze/test evidence; no whole-job success is claimed.")


def scheduler(root, summary):
    original = read(root / "summary.json")
    provenance = read(root / "receipts/provenance.json")
    assert original["complete"] is True and provenance["runtimeDelta"] == ["packages/pdfrx_engine/lib/src/native/worker.dart"]
    summary["sourceCommit"] = provenance["forkCommit"]
    tests = {role: test_counts(root / f"receipts/{role}/worker-tests.jsonl", allow_hook_diagnostics=True) for role in ("before", "after")}
    assert all(item["passed"] == 41 for item in tests.values())
    scans = [read(path) for path in (root / "samples").glob("*-scan.json")]
    assert len(scans) == 14 and sorted(scans, key=lambda row: (row["mode"], row["requests"], row["version"])) == sorted(
        original["operationCounts"], key=lambda row: (row["mode"], row["requests"], row["version"]))
    samples = [read(path) for path in (root / "samples").glob("*.json") if not path.name.endswith("-scan.json")]
    assert len(samples) == 84 and sum(not row["warmup"] for row in samples) == 70
    groups = defaultdict(dict)
    for row in samples:
        if row["warmup"]:
            continue
        key = row["fixture"]["mode"], row["fixture"]["requests"]
        groups[key][row["version"], row["sample"]] = row
    results = []
    for (mode, requests), group in sorted(groups.items()):
        assert set(group) == {(role, i) for role in ("before", "after") for i in range(5)}
        assert len({row["fixtureSha256"] for row in group.values()}) == 1
        values = {role: [group[role, i]["wallMicros"] for i in range(5)] for role in ("before", "after")}
        median = {role: statistics.median(data) for role, data in values.items()}
        raw = next(row for row in original["results"] if row["mode"] == mode and row["requests"] == requests)
        assert all(raw["variants"][role]["wallMicros"]["median"] == median[role] for role in median)
        counts = {row["version"]: row for row in original["operationCounts"] if row["mode"] == mode and row["requests"] == requests}
        assert set(counts) == {"before", "after"} and all(row["timingMeasurement"] is False for row in counts.values())
        for field in ("cooperativeCancellationReads", "cooperativeDisposals", "cooperativeRequests", "cooperativeSteps", "ordinaryCompletions"):
            assert counts["before"][field] == counts["after"][field]
        results.append({"mode": mode, "requests": requests, "samplesPerVariant": 5,
                        "medianWallMs": {role: value / 1000 for role, value in median.items()},
                        "changePercent": (median["after"] / median["before"] - 1) * 100,
                        "pairedChangesPercent": [(values["after"][i] / values["before"][i] - 1) * 100 for i in range(5)],
                        "ordinaryCancellationReads": {role: row["ordinaryCancellationReads"] for role, row in counts.items()},
                        "cooperativeCancellationReads": {role: row["cooperativeCancellationReads"] for role, row in counts.items()}})
    control = next(row for row in results if row["mode"] == "cooperative")
    assert all(value > 0 for value in control["pairedChangesPercent"])
    summary.update(classification="completed-measurement", declaredScopeComplete=True, jobConclusion="success",
                   scope="Synthetic scheduler component A/B; no product UI measurement", sources=original["sources"],
                   sdk=provenance["flutter"], tests=tests, measuredProcesses=70, excludedWarmupProcesses=14,
                   sampleOrder="Five alternating AB/BA pairs per fixture; three AB and two BA pairs",
                   countProbes=14, fixtureResults=results,
                   cooperativeNegativeControl={"workloadAndScanCountsEqual": True, "latencyNonRegression": False,
                                              "slowerInAllFivePairs": True, "result": control},
                   productAdoptionApproved=False)
    summary["limitations"] = [
        "Ordinary-only and 1%-cooperative synthetic queues improve, while cooperative-only is slower in all five pairs.",
        "The cooperative negative control is balanced in work, not in timing; it does not establish non-regression.",
        "Untimed scan instrumentation and uninstrumented AOT latency are separate receipts and are not mixed.",
        "This does not measure actual UI/frame latency or justify adopting the scheduler patch into the application.",
        "Process CPU is quantized by the host clock; zero for a short sample does not mean zero CPU work.",
    ]


def apple(root, summary):
    provenance = read(root / "provenance.json")
    runs = read(root / "runs.json")
    assert len(runs) == 20 and not (root / "summary.json").exists() and not (root / "traces").exists()
    assert provenance["upstreamCommit"] == "683df93e986af19bbcefd22606a417083116847b"
    assert provenance["flutter"]["frameworkVersion"] == "3.50.0"
    assert "timed out after 600 seconds" in read(root / "failure.json")["error"]
    groups = defaultdict(list)
    observations, measured = 0, 0
    for item in runs:
        label = item["label"]
        path = root / f"{label}.json"
        assert sha(path) == item["reportSha256"]
        report, config = read(path), read(root / f"{label}-config.json")
        assert report["measurementComplete"] is True and report["errors"] == []
        assert all(report[key] == config[key] for key in ("backend", "workload", "inputSha256"))
        count = 20 if report["workload"] == "lifecycle" else 3
        assert report["documentsOpened"] == report["documentsClosed"] == count == len(report["observations"])
        assert report["frameTimings"] and all(row["pixelWidth"] > 0 for row in report["observations"])
        corpus = label.rsplit("-" + report["workload"] + "-", 1)[0]
        rows = [row for row in report["observations"] if not row["warmup"]]
        observations += count
        measured += len(rows)
        groups[corpus, report["workload"]].append({"backend": report["backend"], "process": item,
            "observations": len(rows), "textCharacters": sorted({row["textCharacters"] for row in rows}),
            "medianFirstRasterMs": statistics.median(row["firstRasterUs"] for row in rows) / 1000,
            "medianImageReadyMs": statistics.median(row["imageReadyUs"] for row in rows) / 1000})
    assert len(groups) == 5 and all([row["backend"] for row in rows] == ["pdfium", "coregraphics", "coregraphics", "pdfium"] for rows in groups.values())
    summary.update(classification="partial-measurement-workload-timeout", declaredScopeComplete=False,
                   jobConclusion="failure", sourceCommit=provenance["sourceCommit"], upstreamCommit=provenance["upstreamCommit"],
                   sourceRole=provenance["upstreamSourceRole"], compileCompatibility=provenance["compileCompatibility"],
                   sdk=provenance["flutter"], architecture=provenance["architecture"],
                   completedProcesses=20, expectedProcesses=36, completedAbbaGroups=5, expectedAbbaGroups=9,
                   observationsIncludingWarmups=observations, observationsExcludingWarmups=measured,
                   stoppedAt="mikraot-gedolot-genesis-1859-lifecycle-1-pdfium", timeoutSeconds=600,
                   profilerRecordings=0, postCampaignBundleAndSourceVerification=False,
                   completedGroups=[{"corpus": key[0], "workload": key[1], "processes": rows} for key, rows in groups.items()],
                   appAdoptionApproved=False, physicalDeviceMeasured=False)
    summary["limitations"] = [
        "Build and per-report validators passed; the lifecycle workload timed out. This is neither a build failure nor a validator rejection.",
        "The incomplete campaign never executed its final bundle/source guards. No matched whole-campaign integrity is claimed.",
        "Only the first page is sampled for text/render. The MG first page is a cover with no extracted text; Hebrew text comes from UXLC.",
        "No GCC observations or thread traces were produced. The timed-out workload has no final report, so its last native phase is unknown.",
        "Completed raw observations remain available; they are not promoted to a finished E12 comparison or an Otzaria adoption result.",
    ]


def proximity(root, summary):
    base = root / "pdf-5538-proximity"
    validated = read(base / "validated.json")
    assert validated["status"] == "passed"
    summaries = []
    for corpus in ("uxlc-genesis", "mikraot-gedolot-genesis-1859"):
        comparison = read(base / corpus / "comparison.json")
        assert comparison["status"] == "passed" and comparison["uiLatencyCollected"] is False
        per_query = defaultdict(lambda: defaultdict(list))
        rows_count, all_refs = 0, set()
        for name, expected in comparison["reports"].items():
            path = base / name
            assert path.resolve().is_relative_to(base.resolve()) and sha(path) == expected
            report = read(path)
            role = next(role for role, source in comparison["source"].items() if source == report["sourceCommit"])
            assert report["status"] == "passed" and report["querySuite"] == "product-proximity-v1"
            assert report["inputSha256"] == comparison["inputSha256"] and report["uiLatencyCollected"] is False
            assert all(row["parity"] is True for row in report["observations"] + report["microtaskAudit"])
            all_refs.add(report["queryDescriptorsSha256"])
            rows_count += len(report["observations"])
            passes = defaultdict(int)
            for row in report["observations"]:
                if not row["warmup"]:
                    passes[row["queryId"], row["iteration"]] += row["elapsedUs"]
            for query in (item["id"] for item in report["queries"]):
                data = [value for (query_id, _), value in passes.items() if query_id == query]
                assert len(data) == 7
                per_query[query][role].append(statistics.median(data))
        assert len(all_refs) == 1 and len(per_query) == 8
        queries = {}
        for query, roles in per_query.items():
            assert set(roles) == {"baseline", "candidate"} and all(len(data) == 6 for data in roles.values())
            medians = {role: statistics.median(data) for role, data in roles.items()}
            original = comparison["highlightChanges"][query]
            assert medians["baseline"] == original["p50BeforeUs"] and medians["candidate"] == original["p50AfterUs"]
            blocks = []
            for block in comparison["processBlocks"]["blocks"]:
                value = block["queries"][query]
                effect = (statistics.median(value["candidateProcessMediansUs"]) / statistics.median(value["baselineProcessMediansUs"]) - 1) * 100
                assert abs(effect - value["changePercent"]) < 1e-8
                blocks.append(effect)
            queries[query] = {**original, "blockEffectsPercent": blocks, "positiveBlockCount": sum(value > 0 for value in blocks)}
        summaries.append({"corpus": corpus, "inputSha256": comparison["inputSha256"], "source": comparison["source"],
                          "processesPerVariant": 6, "blocks": 3, "queries": queries,
                          "rawHighlightRowsIncludingWarmups": rows_count, "allPageParityChecksPassed": True})
    summary.update(classification="completed-measurement", declaredScopeComplete=True, jobConclusion="success",
                   sourceCommit="f644e08a8ab1d60b63d77f009b73f0d7a62bf883", sourcePlan=validated["plan"],
                   sdk=validated["toolchain"]["sdk"], documents=summaries, totalIndependentProcesses=24,
                   scope="Actual advanced-search ProximityHighlightPattern component on two real books; not UI latency",
                   primaryStatistic="Median of six independent process medians per variant and corpus",
                   uiLatencyMeasured=False)
    summary["limitations"] = [
        "Three ABBA blocks give six fresh processes per side and corpus. Repeated page/pass rows are not independent n.",
        "Primary median effects and the three block effects are different statistics; positive block effects are retained explicitly.",
        "The microtask audit is untimed. Fewer microtasks are a work reduction, not a direct UI/frame latency claim.",
        "This measures the actual advanced-search proximity highlight route, not simple literal search, regex search, or full reader interaction.",
    ]


if __name__ == "__main__":
    method = {"s02": s02, "scheduler": scheduler, "apple": apple, "proximity": proximity}[sys.argv[1]]
    for name in sys.argv[2:]:
        root = Path(name).resolve()
        result = start(root)
        method(root, result)
        destination = root / "analysis-summary.json"
        assert not destination.exists(), destination
        destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
        print(json.dumps({"group": root.name, "classification": result["classification"], "summarySha256": sha(destination)}))
