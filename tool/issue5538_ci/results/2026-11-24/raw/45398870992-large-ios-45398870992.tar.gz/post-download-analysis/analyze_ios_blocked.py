import hashlib
import json
from pathlib import Path
import re
import zipfile

WORKSPACE = Path('/workspace/scratch/8fd497e5cf89')
BASE = WORKSPACE / 'pdf-5538-ci-evidence'
PACKAGE = Path('/home/agent/.pub-cache/hosted/pub.dev/device_info_plus-13.3.0')
IMAGE = 'https://github.com/actions/runner-images/blob/macos-15/20260824.0482/images/macos/macos-15-Readme.md'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


for folder, log_name, scope in (
    ('cleanup-ios-45397314299', 'run.log', 'functional QA of the actual installed PDF reader'),
    ('large-ios-45398870992', 'build.log', 'large real PDF export through iOS Files'),
):
    root = BASE / folder
    receipt = json.loads((root / 'artifact-receipt.json').read_text())
    archive = root / 'artifact.zip'
    assert sha(archive) == receipt['sha256']
    assert archive.stat().st_size == receipt['size']
    members = []
    with zipfile.ZipFile(archive) as zipped:
        for item in zipped.infolist():
            if item.is_dir():
                continue
            local = root / item.filename
            payload = zipped.read(item)
            assert payload == local.read_bytes(), item.filename
            members.append({'path': item.filename, 'bytes': len(payload),
                            'sha256': hashlib.sha256(payload).hexdigest()})
    lines = (root / log_name).read_text().splitlines()
    errors = [{'line': n, 'message': line.strip()} for n, line in enumerate(lines, 1)
              if re.search(r'error:.*no visible @interface.*isiOSAppOnVision', line)]
    assert errors
    assert any('Xcode_16.4.app' in line for line in lines)
    assert any('iPhoneSimulator18.5.sdk' in line for line in lines)
    assert not any(p.name in {'completion.json', 'validated.json', 'test.command.json'} for p in root.rglob('*'))
    readme = PACKAGE / 'README.md'
    plugin = PACKAGE / 'ios/device_info_plus/Sources/device_info_plus/FPPDeviceInfoPlusPlugin.m'
    assert '- Xcode >= 26.1.1' in readme.read_text()
    assert '@available(iOS 26.1, *)' in plugin.read_text()
    summary = {
        'schemaVersion': 1,
        'analysisKind': 'post-download analysis; original ZIP and members remain unchanged',
        'classification': 'blocked-before-device-test',
        'runId': receipt['run'], 'jobId': receipt['job'], 'artifactId': receipt['artifact'],
        'jobUrl': f"https://github.com/yom-chadash/otzaria/actions/runs/{receipt['run']}/job/{receipt['job']}",
        'sourceCommit': receipt['source'], 'jobConclusion': 'failure',
        'artifactZipSha256': receipt['sha256'], 'artifactZipBytes': receipt['size'],
        'scope': scope,
        'completedDeviceScenarios': 0, 'completedPerformanceSamples': 0,
        'productFailureDemonstrated': False,
        'failure': {
            'phase': 'native iOS application compilation, before installation and execution',
            'package': 'device_info_plus', 'lockedVersion': '13.3.0',
            'selectedXcode': '16.4', 'selectedXcodeBuild': '16F6',
            'compileSimulatorSdk': '18.5',
            'diagnostics': errors,
            'explanation': 'The package calls NSProcessInfo.isiOSAppOnVision, which is declared by iOS 26.1 SDK headers. A runtime @available guard does not provide the declaration to the older iOS 18.5 compiler headers.',
            'requiredXcodeFromLockedPackageReadme': '>=26.1.1',
        },
        'runner': {'label': 'macos-15-intel', 'architecture': 'x86_64',
                   'image': 'macos-15', 'imageVersion': '20260824.0482.1',
                   'includedSoftwareFromBothJobLogs': IMAGE,
                   'readmeLabelMap': 'https://github.com/actions/runner-images/blob/main/README.md',
                   'availableRequiredXcode': '26.1.1', 'availableRequiredXcodeBuild': '17B100',
                   'availableRequiredXcodePath': '/Applications/Xcode_26.1.1.app'},
        'dependencySourceEvidence': [
            {'path': str(p.relative_to(PACKAGE)), 'sha256': sha(p)} for p in (readme, plugin)],
        'proposedHarnessCorrection': {'scope': 'the two fork-only jobs.ios workflow sections',
            'developerDir': '/Applications/Xcode_26.1.1.app/Contents/Developer',
            'checks': ['exact Xcode 26.1.1', 'exact iOS Simulator SDK 26.1'],
            'flutterVersionUnchanged': '3.47.7', 'lockedDependenciesUnchanged': True,
            'productCodeUnchanged': True, 'correctionValidatedInCI': False},
        'limitations': [
            'Neither run reached the actual app scenario; this does not establish PDF, Files, clipboard or rendering success or failure.',
            'Simulator runtime selection is distinct from the compile SDK: these runs selected an available iOS 26.2 runtime while compiling against SDK 18.5.',
            'Selecting a sufficient Xcode fixes the demonstrated compiler mismatch; subsequent native build/runtime behavior requires a fresh CI run.',
            'The cleanup job separately passed 97 Dart contracts before native compilation; those are not 97 on-device scenarios.',
        ],
        'rawEvidence': members,
    }
    if folder.startswith('large-'):
        command = json.loads((root / 'build.command.json').read_text())
        assert command['exitCode'] == 65 and not command['timedOut']
        summary['failure'].update(buildExitCode=65, timedOut=False)
        summary['limitations'] = [x for x in summary['limitations'] if '97 Dart' not in x]
    else:
        host = json.loads((root / 'host.json').read_text())
        assert host['commit'] == receipt['source'] and 'x86_64' in host['machine']
        summary['sourceTree'] = host['tree']
    destination = root / 'analysis-summary.json'
    assert not destination.exists()
    destination.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({'file': str(destination), 'sha256': sha(destination),
                      'classification': summary['classification'], 'members': len(members)}))
