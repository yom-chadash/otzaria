"""Post-download validation and descriptive analysis of E03 CI artifacts."""

import hashlib
import json
import math
from pathlib import Path
import statistics
import sys


WORKSPACE = Path(__file__).resolve().parent.parent
MODULES = WORKSPACE / "otzaria-additional-text/tool/issue5538_ci"
sys.path.insert(0, str(MODULES))
import internal_text_run as producer


SOURCE = "4d668424f97f10a3fdb8822f3ba53c0b2e4aaab6"
ORDER = ("control", "instrumented", "instrumented", "control")
JOBS = {"uxlc-genesis": 138461890810, "mikraot-gedolot-genesis-1859": 138461889970}
INPUTS = {
    "uxlc-genesis": ("ce28c3ed6f052b633a943d545f766be88d935c71d71b0b4c23ee172fca71af2e", 54),
    "mikraot-gedolot-genesis-1859": ("92a145512e33c4a3c8f1b1c92d2d79c4db91a49cc921a316201be81bfa85040d", 374),
}
PHASES = ("workerRawBuildUs", "workerNormalizationUs", "workerCleanupUs", "workerUnattributedUs", "outsideMeasuredWorkerBodyUs")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_bytes())


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def stats(values):
    return {"count": len(values), "min": min(values), "median": statistics.median(values),
            "mean": statistics.mean(values), "max": max(values)}


def analyze(label):
    outer = WORKSPACE / "pdf-5538-ci-evidence" / f"pdf-5538-text-worker-{label}"
    base = outer / "pdf-5538-text-worker"
    receipt, summary, provenance = (load(path) for path in (outer / "artifact-receipt.json", base / "summary.json", base / "provenance.json"))
    require(digest(outer / "artifact.zip") == receipt["sha256"], "Artifact ZIP checksum mismatch")
    require((outer / "artifact.zip").stat().st_size == receipt["size"], "Artifact ZIP length mismatch")
    require(summary["measurementComplete"] is True and summary["comparativeEvidence"] is True, "Incomplete evidence")
    require(provenance["commit"] == SOURCE and provenance["dirty"] is False, "Source identity is not frozen")
    require(provenance["productImprovementClaim"] is False and summary["productImprovementClaim"] is False, "Instrumentation is not a product change")
    require(provenance["runOrder"] == list(ORDER), "ABBA order changed")
    require(provenance["sdk"]["frameworkRevision"] == producer.SDK_REVISION
            and provenance["sdk"]["engineRevision"] == producer.ENGINE_REVISION, "SDK identity differs")
    require(summary["document"]["id"] == label
            and (summary["document"]["sha256"], summary["document"]["pageCount"]) == INPUTS[label], "Pinned corpus differs")
    for path, expected in provenance["source"].items():
        if Path(path).name.startswith("internal_text_"):
            require(digest(MODULES / Path(path).name) == expected, f"Analysis helper differs from measured source: {path}")
    require((base / "git-head.log").read_text().strip() == SOURCE == (base / "git-head-after.log").read_text().strip(), "Git head drift")
    require((base / "git-status.log").read_text() == (base / "git-status-after.log").read_text() == "", "Source was dirty")
    require(digest(base / "pdfrx_engine-0.9.3.tar.gz") == producer.ENGINE_ARCHIVE_SHA256 == provenance["engineArchiveSha256"], "Engine archive drift")
    for path, expected in provenance["archiveFiles"].items():
        require(digest(base / "engine-original" / path) == expected, f"Original engine changed: {path}")
    raw_source = (base / "engine-original/lib/src/native/pdfrx_pdfium.dart").read_text()
    require((base / "instrumented/engine/lib/src/native/pdfrx_pdfium.dart").read_text() == producer.instrument_text(raw_source), "Instrumentation exceeds the declared patch")
    for path, expected in provenance["archiveFiles"].items():
        if not (path.startswith("lib/") or path in ("LICENSE", "pubspec.yaml")):
            continue
        if path == "lib/src/native/pdfrx_pdfium.dart":
            continue
        require(digest(base / "instrumented/engine" / path) == expected, f"Unrelated vendor change: {path}")
    require(digest(base / "instrumented/engine/lib/src/issue5538_text_metrics.dart") == provenance["source"]["tool/issue5538_ci/internal_text_metrics.dart"], "Worker instrumentation differs")
    reports, proofs, reference = [], None, None
    configurations, compiler_inputs_verified = [], 0
    compiler_external = []
    for index, side in enumerate(ORDER, 1):
        config = load(base / f"run-{index}-config.json")
        configurations.append(config)
        run = base / f"run-{index}-{side}"
        report = load(run / "report.json")
        seen = producer.validate_report(report, config, side == "instrumented")
        require(report["sourceCommit"] == SOURCE and config["warmup"] == 1 and config["repetitions"] == 3, "Wrong source or repetitions")
        require((config["inputSha256"], config["pageCount"]) == INPUTS[label]
                and report["pdfiumSha256"] == producer.PDFIUM_SHA256, "Corpus/native producer identity differs")
        proofs = seen if proofs is None else proofs
        require(proofs == seen, "All-page text or full geometry hashes differ")
        reference = report["reference"] if reference is None else reference
        require(reference == report["reference"], "Untimed reference geometry or text differs")
        require(report["observations"] == [json.loads(line) for line in (run / "observations.jsonl").read_text().splitlines()], "Raw observations differ")
        published = summary["runs"][index - 1]
        require(published["launch"] == index and published["variant"] == side, "Run receipt order differs")
        require(digest(run / "report.json") == published["reportSha256"], "Report hash mismatch")
        require(digest(run / "observations.jsonl") == published["observationsSha256"], "Observation hash mismatch")
        require(digest(base / side / "probe") == published["executableSha256"], "AOT executable hash mismatch")
        for filename, key in (("reference-normalized.txt", "normalized"), ("reference-before-normalization.txt", "beforeHebrewTransforms")):
            text = producer.text_summary(run / filename)
            require(text["sha256"] == reference[key]["textSha256"] and text["utf16CodeUnits"] == reference[key]["utf16CodeUnits"], "Reference text bytes/count differs")
        reports.append(report)
    remote_base = Path(configurations[0]["output"]).parent
    for side in ("control", "instrumented"):
        deps = load(base / side / "compiler-inputs.json")
        external = {}
        for source, expected in deps.items():
            path = Path(source)
            if path.is_relative_to(remote_base):
                require(digest(base / path.relative_to(remote_base)) == expected, f"Preserved compiler input changed: {source}")
                compiler_inputs_verified += 1
            else:
                external[source] = expected
        compiler_external.append(external)
        require(digest(base / side / "internal_text_probe.dart") == provenance["source"]["tool/issue5538_ci/internal_text_probe.dart"], "Probe entry point differs")
        command = load(base / side / "compile-command.json")
        require(f"-DTEXT_SOURCE_COMMIT={SOURCE}" in command and "-DTEXT_MODE=dart-aot" in command, "Compiled identity missing")
    require(compiler_external[0] == compiler_external[1], "Control and instrumented use different external dependencies")
    private_packages = [load(base / side / "packages.json") for side in ("control", "instrumented")]
    for config, side in zip(private_packages, ("control", "instrumented")):
        entry = next(p for p in config["packages"] if p["name"] == "pdfrx_engine")
        expected = remote_base / ("engine-original" if side == "control" else "instrumented/engine")
        require(entry["rootUri"] == expected.as_uri() + "/", "Variant does not use the declared engine source")
        entry["rootUri"] = "<declared-engine-variant>"
    require(private_packages[0] == private_packages[1], "More than the engine package mapping differs")
    require(producer.timing_summary(reports) == summary["timing"], "Published timing totals differ")
    require(sum(len(r["observations"]) for r in reports) == summary["parityObservations"], "Parity count differs")
    comparison = load(base / "reference-comparison.json")
    require(comparison == summary["referenceComparison"], "Reference comparison differs from summary")
    require(comparison["pageNumber"] == producer.REFERENCE_PAGES[label] and comparison["timed"] is False, "Wrong or timed reference page")
    for name, expected in comparison["outputs"].items():
        require(producer.text_summary(base / "reference" / f"{name}.txt") == expected, f"Reference summary does not match bytes: {name}")
    instrumented = summary["timing"]["instrumented"]["processes"]
    passes = [row for process in instrumented for row in process["passes"]]
    denominator = sum(row["callerRawLoadUs"] for row in passes)
    component_totals = {field: sum(row[field] for row in passes) for field in PHASES}
    require(sum(component_totals.values()) == denominator, "Timing components do not partition the caller interval")
    components = {field: {"meanCompletePassMs": total / len(passes) / 1000,
                          "fractionOfMeasuredCallerTimePercent": total * 100 / denominator,
                          "completePassUs": stats([row[field] for row in passes])}
                  for field, total in component_totals.items()}
    process_rows = []
    for index, report in enumerate(reports, 1):
        values = [sum(r["callerRawLoadUs"] for r in report["observations"] if r["iteration"] == iteration)
                  for iteration in range(1, 4)]
        process_rows.append({"launch": index, "variant": ORDER[index - 1], "measuredPassCallerUs": values,
                             "processMedianCallerUs": statistics.median(values), "processMeanCallerUs": statistics.mean(values)})
    pairs = []
    for control, observed in ((0, 1), (3, 2)):
        ratio = process_rows[observed]["processMedianCallerUs"] / process_rows[control]["processMedianCallerUs"]
        pairs.append({"controlLaunch": control + 1, "instrumentedLaunch": observed + 1,
                      "observedInstrumentedCallerChangePercent": (ratio - 1) * 100})
    ratio = math.sqrt(math.prod(1 + row["observedInstrumentedCallerChangePercent"] / 100 for row in pairs))
    page_proofs = []
    for page, values in sorted(proofs.items()):
        proof = dict(zip(producer.PROOF_FIELDS, values))
        instrumented_rows = [row for r in reports if r["instrumented"] for row in r["observations"]
                             if not row["warmup"] and row["pageNumber"] == page]
        page_proofs.append({"pageNumber": page, **proof,
                            "instrumentedCallerMedianUs": statistics.median(row["callerRawLoadUs"] for row in instrumented_rows),
                            "instrumentedRawBuildMedianUs": statistics.median(row["worker"]["workerRawBuildUs"] for row in instrumented_rows),
                            "instrumentedNormalizationMedianUs": statistics.median(row["worker"]["workerNormalizationUs"] for row in instrumented_rows)})
    conclusions = {
        "dominantMeasuredComponent": "Worker raw-build: PDFium calls plus Dart string/rectangle construction; the observations do not separate native extraction from this Dart construction.",
        "normalization": "Hebrew normalization accounts for about one tenth of the instrumented caller interval. Two reference pages have unchanged text/geometry when both Hebrew flags are off; this does not establish that normalization is redundant for other pages or encodings.",
        "residual": "Queue/dispatch/arena/return plus instrumentation bookkeeping remain combined in the outside-worker residual. It is not an isolated transfer measurement or a concurrent-queue measurement.",
        "overhead": "The uninstrumented controls and instrumented callers are close in these ABBA observations. A small or negative observed difference is not evidence of product acceleration or exact zero observer overhead.",
        "productAction": "Prioritize avoiding repeated raw extraction or optimizing the upstream raw-text construction contract. The existing app LRU thrash evidence remains relevant; these source-instrumented diagnostics are not an app optimization.",
    }
    if label == "uxlc-genesis":
        conclusions["reference"] = "UXLC page 1 contains inferred internal spaces, e.g. אֱ לֹהִ֑ ים, before Hebrew normalization as well as after it. Literal and marks-tolerant אלהים both have zero hits in PDFium and the two Poppler layouts. This does not prove how space characters were encoded in PDF objects."
    else:
        conclusions["reference"] = "MG page 10 has 3,954 Hebrew letters and 378 marks in every extractor. Literal אלהים has zero hits; the marks-tolerant query has one hit (אֶלְהִים) in PDFium with flags both on/off and in Poppler layout, but none in Poppler raw. Extraction order/spacing differs, and OCR accuracy has no ground truth here."
    result = {
        "status": "validated", "section": "E03", "runId": 45398870991, "jobId": JOBS[label],
        "url": f"https://github.com/yom-chadash/otzaria/actions/runs/45398870991/job/{JOBS[label]}",
        "artifactId": receipt["artifactId"], "archiveSha256": receipt["sha256"], "archiveBytes": receipt["size"],
        "sourceCommit": SOURCE, "document": summary["document"],
        "sourceFiles": provenance["source"], "engineArchiveSha256": provenance["engineArchiveSha256"],
        "pdfiumSha256": reports[0]["pdfiumSha256"], "sourceCleanBeforeAfter": True,
        "validation": {"allPageTextAndGeometryHashesIdentical": True,
                       "allReportsAndRawJsonlHashesVerified": True, "aotExecutableHashesVerified": True,
                       "originalEngineFilesVerified": len(provenance["archiveFiles"]),
                       "instrumentedPatchMatchesDeclaredGenerator": True,
                       "preservedCompilerInputFilesVerified": compiler_inputs_verified,
                       "externalCompilerDependencyReceiptsIdentical": True,
                       "externalDependencyFilesRehashedAfterDownload": False,
                       "nativeGeometryCoordinatesArchived": False,
                       "geometryVerification": "Compare complete-coordinate hashes computed inside each native producer, across every page/pass/process; no coordinate sampling.",
                       "referenceFileBytesAndUtf16CountsRecomputed": True,
                       "observationsIncludingWarmup": summary["parityObservations"],
                       "measuredObservations": sum(not row["warmup"] for report in reports for row in report["observations"])},
        "textPerCompletePass": {"utf16CodeUnits": sum(row["utf16CodeUnits"] for row in page_proofs),
                                "characterRects": sum(row["characterRects"] for row in page_proofs),
                                "pagesWithText": sum(row["utf16CodeUnits"] > 0 for row in page_proofs),
                                "scope": "PdfPageRawText before structured formatting; not comparable to earlier PdfPageText formatted-text character totals"},
        "independentProcessesPerVariant": 2, "passesPerProcess": {"warmup": 1, "measured": 3},
        "processes": process_rows,
        "controlInstrumentedCalibration": {"adjacentPairs": pairs,
            "balancedObservedInstrumentedCallerChangePercent": (ratio - 1) * 100,
            "observerOverheadIsolated": False, "productImprovementClaim": False},
        "instrumentedComponents": components,
        "instrumentedMeanCompletePassCallerMs": denominator / len(passes) / 1000,
        "componentAggregation": "Sum each component over six measured complete passes, then divide by six; percentage uses the same summed caller denominator so components add to 100%.",
        "referenceComparison": comparison,
        "referenceNormalizedVersusFlagsOff": {
            "textBytesIdentical": reference["normalized"]["textSha256"] == reference["beforeHebrewTransforms"]["textSha256"],
            "fullGeometryHashIdentical": reference["normalized"]["geometrySha256"] == reference["beforeHebrewTransforms"]["geometrySha256"],
            "pageNumber": reference["pageNumber"], "proof": reference},
        "pages": page_proofs, "conclusions": conclusions,
        "limitations": summary["limitations"] + [
            "Each document uses its own CI job/host; cross-document timings are not paired product effects.",
            "Only two processes per variant; six measured passes per side are not six independent launches.",
            "Per-page proof hashes cover all text/geometry, but the artifact does not preserve every page's full coordinate array for independent re-extraction.",
            "The flag-off comparison covers only one content page per document; it cannot justify disabling Hebrew normalization globally.",
        ],
        "analysisScriptSha256": digest(Path(__file__)),
    }
    destination = outer / "analysis-summary.json"
    if destination.exists():
        previous = load(destination)
        require(previous.get("runId") == result["runId"] and previous.get("artifactId") == result["artifactId"], "Unrelated analysis exists")
    temporary = destination.with_suffix(".tmp")
    temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(destination)
    print(json.dumps({"document": label, "output": str(destination), "meanCallerMs": result["instrumentedMeanCompletePassCallerMs"],
        "components": {key: {name: value for name,value in row.items() if name != "completePassUs"} for key,row in components.items()},
        "observedInstrumentedChangePercent": (ratio-1)*100,
        "referencePage": reference["pageNumber"], "counts": result["textPerCompletePass"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    for name in JOBS:
        analyze(name)
