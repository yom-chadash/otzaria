"""Post-download analysis of the original failed installed-plugin PDF evidence.

This script does not run the app and does not edit original artifact members.
Usage: python3 analyze_nativeqa_failure.py ARTIFACT_DIRECTORY
"""
from pathlib import Path, PurePosixPath
import hashlib
import json
import sys
import zipfile

SOURCE = 'b103bdf2e3ee2fc1e389af30aa7d4bec4b6af341'
PIN = 'cdea38083d06b445b4ec67d8345109a0457924af'
PDF_SHA = '45864014ff59109585244df6b4fab736d45996531a8eb24ff248a8090406d939'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def analyze(root):
    receipt = json.loads((root / 'artifact-receipt.json').read_text())
    archive = root / 'artifact.zip'
    assert archive.stat().st_size == receipt['size']
    assert sha(archive) == receipt['sha256'] == receipt['verifiedArchiveSha256']
    members = []
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            name = PurePosixPath(info.filename)
            assert not name.is_absolute() and '..' not in name.parts
            original = z.read(info)
            actual = root / info.filename
            assert actual.is_file() and not actual.is_symlink()
            assert actual.read_bytes() == original, info.filename
            members.append(info.filename)
    assert len(members) == receipt['extractedFiles']
    android = 'android' in root.name
    report_path = root / ('partial-installed-plugin-report.json' if android else 'device/installed-plugin-report.json')
    raw = json.loads(report_path.read_text())
    pdf = raw['pdfRuntime']
    assert raw['commit'] == receipt['sourceCommit'] == SOURCE
    assert raw['status'] == pdf['status'] == 'failed'
    view = pdf['steps']['view']
    assert view['status'] == 'failed'
    assert "Expected: contains 'bundlepage1'" in view['error']
    assert 'Actual: <null>' in view['error']
    assert '_PdfRuntime.checkNativePage' in pdf['error']
    assert all(v['status'] == 'notRun' for k, v in pdf['steps'].items() if k != 'view')
    fixture = pdf['fixture']
    assert fixture['sha256'] == PDF_SHA and fixture['pages'] == 4 and fixture['bytes'] == 1631
    proof = {'artifactContainsPdfBytes': False, 'scope': 'The Android report declares the fixture hash; the ZIP does not retain the generated PDF bytes.'}
    if not android:
        from pypdf import PdfReader
        path = root / 'device/bundle-runtime.pdf'
        assert sha(path) == PDF_SHA and path.stat().st_size == fixture['bytes']
        extracted = [page.extract_text() for page in PdfReader(path).pages]
        assert len(extracted) == 4
        assert all(f'bundlepage{i}' in text for i, text in enumerate(extracted, 1))
        proof = {'artifactContainsPdfBytes': True, 'file': str(path.relative_to(root)), 'sha256': sha(path), 'independentExtractor': 'pypdf', 'pageTexts': extracted, 'scope': 'Independent content check only; not proof of PDFium text/raster or app recovery.'}
    steps_path = root / 'workflow-job-steps.json'
    steps = json.loads(steps_path.read_text())
    log_path = root / 'workflow-job.log'
    assert log_path.is_file()
    plugin_phases = [{'name': p['name'], 'status': p['status']} for p in raw['phases']]
    return {
        'schemaVersion': 1,
        'analysisKind': 'Post-download failure analysis; no remeasurement',
        'repository': 'yom-chadash/otzaria',
        'runId': receipt['runId'],
        'jobId': steps['jobId'],
        'runUrl': f"https://github.com/yom-chadash/otzaria/actions/runs/{receipt['runId']}",
        'jobUrl': f"https://github.com/yom-chadash/otzaria/actions/runs/{receipt['runId']}/job/{steps['jobId']}",
        'artifactId': receipt['artifactId'],
        'artifactZipSha256': receipt['sha256'],
        'artifactZipBytes': receipt['size'],
        'verifiedOriginalFiles': len(members),
        'sourceCommit': SOURCE,
        'pdfrxCompatiblePin': PIN,
        'platform': raw['platform'],
        'buildMode': raw['buildMode'],
        'flutterVersion': raw['flutterVersion'],
        'dartVersion': raw['dartVersion'],
        'physicalDeviceAcceptance': raw['physicalDeviceAcceptance'],
        'rawReport': str(report_path.relative_to(root)),
        'rawReportSha256': sha(report_path),
        'workflowJobSteps': {'path': steps_path.name, 'sha256': sha(steps_path), 'scope': 'Supplemental decoded connector response; not an original ZIP member'},
        'workflowJobLog': {'path': log_path.name, 'sha256': sha(log_path), 'scope': 'Supplemental decoded connector log; saved as UTF-8 with the supplied line endings; not an original ZIP member'},
        'outcome': 'Native app build reached PDF runtime; first-page text check failed. No complete PDF functional pass.',
        'observedPdfFailure': {'step': 'view', 'error': view['error'], 'stackSite': 'installed_plugin_pdf_runtime.dart:689 _PdfRuntime.checkNativePage', 'followingSteps': {k: v['status'] for k, v in pdf['steps'].items() if k != 'view'}},
        'pluginPhases': plugin_phases,
        'pluginPassedCount': sum(p['status'] == 'passed' for p in plugin_phases),
        'fixture': {'sha256': PDF_SHA, 'pages': 4, 'bytes': 1631, 'independentCheck': proof},
        'cleanupEvidence': {
            'ownedDocumentsRemaining': pdf['ownedDocumentsRemaining'],
            'ownedTabsRemaining': pdf['ownedTabsRemaining'],
            'indexingActiveAfter': pdf['indexingActiveAfter'],
            'limitation': 'Existing final cleanup counters reached zero, but the old harness tracked only the initially captured viewer document; this does not establish closure of every replacement owner.'
        },
        'sourceGroundedDiagnosis': {
            'classification': 'Concrete harness lifetime defect found in source; occurrence of its owner replacement in this run remains an inference.',
            'observedSourceFacts': [
                'The b103 harness stores controller.document in _OwnedPdfViewer before awaiting target navigation and keeps reading that snapshot.',
                'S02 font recovery can publish a replacement on the same document reference; publication disposes the old native document.',
                'The locked native loadText returns null for a disposed document or an unloaded page. The first native page is measured before openFile returns.',
                'The old close guard waits for only the initially captured owner, so it can miss a replacement owner.'
            ],
            'sources': [
                f'https://github.com/yom-chadash/otzaria/blob/{SOURCE}/integration_test/support/installed_plugin_pdf_runtime.dart',
                f'https://github.com/yom-chadash/otzaria/blob/{SOURCE}/lib/pdf_book/utils/pdf_font_fallback.dart',
                f'https://github.com/yom-chadash/pdfrx/blob/{PIN}/packages/pdfrx/lib/src/pdf_document_ref.dart',
                f'https://github.com/yom-chadash/pdfrx/blob/{PIN}/packages/pdfrx_engine/lib/src/native/pdfrx_pdfium.dart'
            ],
            'missingRuntimeEvidence': 'The original raw report has no live published owner/generation identity at the failed loadText boundary; it does not directly prove which reload occurred.',
            'repairUnderTest': 'Resolve the live published owner for each operation, verify its identity before/after native awaits, record every observed generation, and await all observed native closes after detach.',
            'productDefectEstablished': False,
            'productCorrectnessEstablished': False
        },
        'limitations': [
            'No performance conclusion is drawn from this failed correctness run or from its incidental timings.',
            'Plugin phases that passed do not imply the subsequent PDF indexing/export/cancellation/lifecycle phases passed.',
            'The generation-aware harness fix requires its own regression and native CI evidence; no result is substituted into these original raw files.',
            'Android is an emulator run, and Linux uses the hosted native WPE/Xvfb setup; these are not physical-device acceptance results.'
        ]
    }


if __name__ == '__main__':
    root = Path(sys.argv[1]).resolve()
    result = analyze(root)
    output = root / 'analysis-summary.json'
    data = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if output.exists():
        assert output.read_text() == data, 'Existing frozen summary differs; do not overwrite.'
    else:
        output.write_text(data)
    print(json.dumps({'group': root.name, 'jobId': result['jobId'], 'artifactId': result['artifactId'], 'artifactZipSha256': result['artifactZipSha256'], 'summarySha256': sha(output), 'pluginPassed': result['pluginPassedCount']}))
