#!/usr/bin/env python3
"""Recheck immutable owner-QA artifacts and summarize actual JSONL events."""
import collections
import hashlib
import json
from pathlib import Path
import sys
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def analyze(root):
    receipt = json.loads((root / 'artifact-receipt.json').read_text())
    archive = (root / 'artifact.zip').read_bytes()
    assert len(archive) == receipt['bytes']
    assert digest(archive) == receipt['sha256']
    with zipfile.ZipFile(root / 'artifact.zip') as zipped:
        names = [info.filename for info in zipped.infolist() if not info.is_dir()]
        assert len(names) == len(set(names)) == receipt['verifiedOriginalMembers'] == 5
        assert set(names) == {item['path'] for item in receipt['members']}
        for item in receipt['members']:
            original = zipped.read(item['path'])
            local = (root / item['path']).read_bytes()
            assert original == local
            assert len(local) == item['bytes'] and digest(local) == item['sha256']
    source = (root / 'pdf-product-source.txt').read_text().strip()
    assert source == receipt['source']
    source_receipt = json.loads((root / 'source-commit-api.json').read_text())
    commit = source_receipt['commit']
    assert commit['sha'] == source and len(commit['parents']) == 1
    delta = [file['filename'] for file in commit['files']]
    assert len(delta) == 1 and delta[0].startswith('.github/workflows/') and delta[0].endswith('.yml')
    sdk = json.loads((root / 'pdf-product-sdk.json').read_text())
    expected_sdk = {
        'frameworkVersion': '3.47.7',
        'frameworkRevision': 'abaf9c523780a608bd46686fd5e53740a07077f8',
        'engineRevision': 'deb287481e3ce9468f3434937ced4240a70539ca',
        'dartSdkVersion': '3.13.5',
    }
    for key, value in expected_sdk.items():
        assert sdk[key] == value, (key, sdk[key])
    analyze_log = (root / 'pdf-product-analyze.log').read_text()
    assert 'No issues found!' in analyze_log
    events = [json.loads(line) for line in (root / 'pdf-product-tests.json').read_text().splitlines() if line.strip()]
    assert sum(event['type'] == 'done' for event in events) == 1
    assert events[-1]['type'] == 'done' and events[-1]['success'] is True
    assert not [event for event in events if event['type'] == 'error']
    suites = {event['suite']['id']: event['suite'] for event in events if event['type'] == 'suite'}
    tests = {event['test']['id']: event['test'] for event in events if event['type'] == 'testStart'}
    counts = collections.defaultdict(collections.Counter)
    completed = set()
    hidden = 0
    for event in events:
        if event['type'] != 'testDone':
            continue
        test_id = event['testID']
        assert test_id in tests and test_id not in completed
        completed.add(test_id)
        assert event['result'] == 'success' and event['skipped'] is False
        if event['hidden']:
            hidden += 1
            continue
        path = suites[tests[test_id]['suiteID']]['path'].replace('\\', '/')
        assert '/test/' in path
        path = 'test/' + path.split('/test/', 1)[1]
        counts[path]['passed'] += 1
    assert completed == set(tests)
    selected = {key: dict(value) for key, value in sorted(counts.items())}
    total = sum(value['passed'] for value in selected.values())
    assert selected['test/pdf_book/pdf_native_owner_tracker_test.dart']['passed'] == 6
    legacy = selected.get('test/tool/perf_probe/pdf_multi_window_test.dart', {}).get('passed', 0)
    retained = selected.get('test/pdf_book/pdf_multi_window_contract_test.dart', {}).get('passed', 0)
    if 'owner-product-' in root.name:
        assert legacy == 38 and retained == 0 and total == 245
    elif 'owner-cleanup-' in root.name:
        assert legacy == 0 and retained == 24 and total == 91
    else:
        assert legacy == 0 and retained == 24 and total == 266
    log = (root / 'pdf-product-tests.log').read_text()
    assert f'+{total}: All tests passed!' in log
    summary = {
        'schemaVersion': 1,
        'classification': 'completed-source-analysis-and-targeted-correctness',
        'declaredScopeComplete': True,
        'nativeApplicationOutcome': 'not-measured-by-this-artifact',
        'provenance': {
            'repository': 'yom-chadash/otzaria',
            'run': receipt['run'], 'job': receipt['job'], 'artifact': receipt['artifact'],
            'runUrl': f"https://github.com/yom-chadash/otzaria/actions/runs/{receipt['run']}/job/{receipt['job']}",
            'archiveBytes': receipt['bytes'], 'archiveSha256': receipt['sha256'],
            'ciSourceCommit': source,
            'productSourceCommit': commit['parents'][0]['sha'],
            'ciOnlyDeltaPaths': delta,
            'originalMembersVerified': len(names),
            'originalFiles': receipt['members'],
            'sourceCommitApiReceipt': {'path': 'source-commit-api.json', 'sha256': digest((root / 'source-commit-api.json').read_bytes()), 'origin': 'post-download connector response, not an artifact member'},
        },
        'sdk': expected_sdk,
        'fullAnalyze': {'passed': True, 'evidence': 'pdf-product-analyze.log'},
        'tests': {'passed': total, 'failed': 0, 'skipped': 0, 'hiddenSuccessfulLoadingAndTeardownEvents': hidden, 'testStartAndDoneIdsMatch': True, 'jsonlDoneSuccess': True, 'perSuite': selected},
        'requiredOwnerContracts': {'ownerTracker': 6, 'legacyMultiWindow': legacy, 'retainedMultiWindow': retained},
        'limitations': [
            'These artifacts prove source analysis and the selected correctness tests, not an actual installed application run or native two-window completion.',
            'No timings are interpreted as performance evidence; hidden loading and teardown events are excluded from the stated test count.',
            'The analyzed CI commit differs from its product parent only in the listed workflow; exact GitHub commit response is retained separately as post-download provenance.',
        ],
        'analysisOrigin': 'post-download analysis; raw original ZIP members unchanged',
        'analysisScript': {'path': 'pdf-5538-analysis-tools/analyze_owner_qa.py', 'sha256': digest(Path(__file__).read_bytes())},
    }
    output = root / 'analysis-summary.json'
    with output.open('x') as stream:
        json.dump(summary, stream, ensure_ascii=False, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'group': root.name, 'passed': total, 'source': source, 'product': commit['parents'][0]['sha'], 'summarySha256': digest(output.read_bytes())}))


if __name__ == '__main__':
    for argument in sys.argv[1:]:
        analyze(Path(argument))
