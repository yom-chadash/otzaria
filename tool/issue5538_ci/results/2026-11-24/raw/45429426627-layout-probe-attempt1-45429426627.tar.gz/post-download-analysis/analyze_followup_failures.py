"""Reproduce post-download classifications for failed fork-only gates."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import zipfile


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def verify_zip(root):
    receipt = read(root / 'artifact-receipt.json')
    archive = root / 'artifact.zip'
    expected = receipt.get('verifiedArchiveSha256', receipt['sha256'])
    assert sha(archive) == expected
    with zipfile.ZipFile(archive) as source:
        files = [item for item in source.infolist() if not item.is_dir()]
        assert len({item.filename for item in files}) == len(files)
        for item in files:
            assert (root / item.filename).read_bytes() == source.read(item)
    return {'artifactZipSha256': expected, 'artifactZipBytes': archive.stat().st_size,
            'verifiedOriginalFiles': len(files)}


def windows(root):
    host, report, completion = (read(root / name) for name in ('host.json', 'run/report.json', 'run/completion.json'))
    source = 'b103bdf2e3ee2fc1e389af30aa7d4bec4b6af341'
    assert host['sourceSha'] == completion['sourceSha'] == source
    assert host['status'] == report['status'] == completion['status'] == 'failed'
    assert report['steps']['open']['error'] == 'Bad state: Reader document identity changed.'
    assert completion['unhandledErrors'] == []
    assert host['source']['beforeBuild'] == host['source']['afterBuild']
    assert host['source']['beforeBuild']['clean'] is True
    assert host['engineIdentity'] == completion['engineIdentity']
    assert completion['engineIdentity']['bundleSha256'] == host['expectedEngineSha256']
    return {'section': 'Q02', 'runId': 45425218382, 'jobId': 138555238966, 'artifactId': 14938161402,
        'sourceCommit': source, 'classification': 'failed-correctness-harness-lifecycle',
        'platform': 'windows', 'buildMode': 'release', 'flutter': host['flutter'],
        'observedFailure': report['steps']['open'], 'reportSha256': sha(root / 'run/report.json'),
        'completionSha256': sha(root / 'run/completion.json'),
        'sourceBuildReceiptsEqualAndClean': True, 'engineIdentityRoundtrip': True,
        'reportedTrackedOwnerTeardown': report['steps']['teardown'],
        'twoWindowScenarioComplete': False, 'performanceMeasurement': False,
        'sourceGroundedDiagnosis': 'The old harness captures controller.document in _Reader before navigation, '
            'then requires the same owner forever. S02 recovery permits replacing the document on the same reference. '
            'The observed failure proves the captured and current owners differed; it does not identify a bad product rendering.',
        'limitations': ['Search/index/export/window lifecycle acceptance did not complete.',
            'The old cleanup tracked the initially captured document; its zero counters do not prove every replacement owner closed.',
            'Build/source and engine identity receipts are retained, but this failed host report has no complete post-run identity guard.']}


def apple(root):
    receipt = read(root / 'artifact-receipt.json')
    ios = receipt['jobId'] == 138555238942
    assert receipt['jobId'] in {138555238890, 138555238942}
    report_path = (root / 'partial-device-output/installed-pdf-ios-report.json' if ios else
                   root / 'apple-installed-pdf/device/installed-plugin-report.json')
    report = read(report_path)
    runtime = report['pdfRuntime']
    assert report['commit'] == 'b103bdf2e3ee2fc1e389af30aa7d4bec4b6af341'
    assert report['status'] == runtime['status'] == 'failed'
    view = runtime['steps']['view']
    assert view['status'] == 'failed' and "contains 'bundlepage1'" in view['error'] and 'Actual: <null>' in view['error']
    assert 'installed_plugin_pdf_runtime.dart:689' in runtime['error']
    assert all(step['status'] == 'notRun' for name, step in runtime['steps'].items() if name != 'view')
    phases = [{'name': phase['name'], 'status': phase['status']} for phase in report.get('phases', [])]
    return {'section': 'Q02', 'runId': receipt['runId'], 'jobId': receipt['jobId'], 'artifactId': receipt['artifactId'],
        'sourceCommit': report['commit'], 'classification': 'failed-correctness-harness-lifecycle',
        'platform': report['platform'], 'buildMode': report['buildMode'], 'flutterVersion': report['flutterVersion'],
        'physicalDeviceAcceptance': False, 'rawReport': report_path.relative_to(root).as_posix(), 'rawReportSha256': sha(report_path),
        'observedFailure': view, 'followingPdfSteps': {name: step['status'] for name, step in runtime['steps'].items() if name != 'view'},
        'pluginPhases': phases, 'pluginPassedCount': sum(phase['status'] == 'passed' for phase in phases),
        'fixture': runtime['fixture'], 'trackedOwnerCleanup': {key: runtime.get(key) for key in
            ['ownedDocumentsRemaining', 'ownedTabsRemaining', 'indexingActiveAfter']},
        'sourceGroundedDiagnosis': 'The runtime reads the native document captured before navigation; S02 may publish and dispose replacement owners. '
            'This source-level lifetime defect explains the null-text symptom, but the old raw report does not identify the replacement event.',
        'performanceMeasurement': False, 'limitations': ['No complete PDF view/index/export/native-module/teardown acceptance passed.',
            'The old cleanup counters cover the initially captured owners and do not prove every replacement owner closed.',
            'No product rendering defect or performance regression is established by this failed harness.']}


def layout_first(root):
    metadata = read(root / 'workflow-metadata.json')
    job = metadata['jobs']['jobs'][0]
    assert job['id'] == 138570274623 and job['conclusion'] == 'failure'
    failed = [step for step in job['steps'] if step['conclusion'] == 'failure']
    assert len(failed) == 1 and failed[0]['number'] == 5
    log = (root / 'workflow-job.log').read_text()
    assert 'jq not found. Install it from' in log
    return {'section': 'M02', 'runId': 45429426627, 'jobId': job['id'], 'artifactId': 14937881893,
        'sourceCommit': '41cc03a19889e5719d76ce70abdf5f272058f3d3',
        'classification': 'infrastructure-failure-before-sdk-setup-or-measurement',
        'failedStep': failed[0], 'cause': 'The Flutter setup action stopped because jq was not installed in the container.',
        'nativeHandshakeCompleted': False, 'completedProcesses': 0, 'completedObservations': 0,
        'performanceMeasurement': False, 'limitations': ['Artifact contains only container preflight OS/package receipts; no layout measurements ran.']}


def wrap_import(root):
    failure = read(root / 'pdf-5538-wrap-search/failure.json')
    assert failure['completedIndependentProcesses'] == 0
    assert "Undefined name 'SearchEngineLibrary'" in failure['error'] and 'wrap_search_app.dart:499:9' in failure['error']
    return {'section': 'M02 wrap search', 'runId': 45427001661, 'jobId': 138561608155, 'artifactId': 14936956779,
        'sourceCommit': '063d4eec0696b5c48452c28e8f21fd88df6aea7d',
        'classification': 'infrastructure-failure-before-build-or-measurement',
        'cause': 'Target analysis rejected missing SearchEngineLibrary import before the first profile build.',
        'failure': failure, 'completedProcesses': 0, 'completedObservations': 0, 'performanceMeasurement': False,
        'limitations': ['Preparation/overlay receipts prove input construction only; no search workload ran.']}


def layout_third(root):
    report = read(root / 'pdf-5538-layout-probe/report.json')
    log = (root / 'pdf-5538-layout-probe/run-0-baseline/test.log').read_text()
    assert report['rows'] == [] and report['status'] == 'failed'
    assert 'before its native identity handshake' in report['error']
    assert 'package_graph.json' in log
    return {'section': 'M02', 'runId': 45431072132, 'jobId': 138576188847, 'artifactId': 14938119909,
        'sourceCommit': report['orchestrator']['commit'], 'classification': 'infrastructure-failure-before-native-handshake',
        'cause': 'Flutter exited before the first native identity handshake; its package overlay had no sibling package_graph.json.',
        'diagnostics': [re.sub(r'\x1b\[[0-9;]*m', '', line) for line in log.splitlines() if 'package_graph.json' in line],
        'sourcePlan': report['plan'], 'sdk': report['sdk'], 'pdfiumSha256': report['pdfiumSha256'],
        'reportSha256': sha(root / 'pdf-5538-layout-probe/report.json'),
        'nativeHandshakeCompleted': False, 'completedProcesses': 0, 'completedObservations': 0,
        'performanceMeasurement': False, 'limitations': ['The first Flutter test process started but did not enter the authenticated measurement workload.',
            'Debug/JIT work-count and native parity evidence were planned; no count, parity or latency conclusion is supported by this attempt.']}


def navigation(root, validator):
    receipt = read(root / 'artifact-receipt.json')
    job = read(root / 'workflow-job-steps.json')
    before, after = read(root / 'before-tests.json'), read(root / 'after-tests.json')
    assert before['sourcesVerified'] and before['sdkVerified'] and after['sourcesVerified'] and after['sdkVerified']
    assert before['resolvedDependencies'] == after['resolvedDependencies']
    assert next(step for step in job['steps'] if step['number'] == 15)['conclusion'] == 'skipped'
    assert not (root / 'candidate-tests.jsonl').exists()
    common = {'section': 'navigation correctness', 'runId': 45430642965, 'jobId': job['id'],
        'artifactId': receipt['artifactId'], 'sourceCommit': receipt['sourceCommit'],
        'originalProductCommit': 'cdea38083d06b445b4ec67d8345109a0457924af',
        'candidateProductCommit': '4f7d95e3d9e7d932a3675d837bfa3f8e7f3be703',
        'sourceAndDependencyGuardsPassed': True, 'candidateAnalyzePassed': True, 'candidateTestsRun': 0,
        'performanceMeasurement': False}
    if job['conclusion'] == 'cancelled':
        assert job['id'] == 138574689417 and not (root / 'baseline-tests.jsonl').exists()
        assert (root / 'baseline-tests.log').read_bytes() == b''
        return {**common, 'classification': 'cancelled-before-recorded-regression-results',
            'recordedVisibleTestCompletions': 0,
            'limitations': ['Cancellation interrupted the baseline test step; the artifact has no JSON test stream or exit receipt.',
                'No baseline or candidate correctness result and no performance measurement can be inferred.']}
    assert job['id'] == 138574689556 and job['conclusion'] == 'failure'
    assert sha(validator) == '972da42cc2f66866bdde1c2b0a4b8c1b35ef363b3b709084f19f35d234b9fe3d'
    spec = importlib.util.spec_from_file_location('verified_navigation_gate', validator)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    report = module.validate_report(root / 'baseline-tests.jsonl', int((root / 'baseline-exit.txt').read_text()), True)
    validation = root / 'baseline-validated.json'
    payload = (json.dumps(report, indent=2) + '\n').encode()
    if validation.exists():
        assert validation.read_bytes() == payload
    else:
        validation.write_bytes(payload)
    return {**common, 'classification': 'baseline-regression-reproduced-gate-parser-failed-before-candidate',
        'baseline': report, 'gateFailure': 'The old parser expected direct TestFailure JSON; Flutter emitted widget-test wrappers and the exact assertions in print events.',
        'postDownloadValidation': {'path': validation.name, 'sha256': sha(validation),
            'validatorSha256': sha(validator), 'origin': 'Post-download derivation; not an original artifact member'},
        'limitations': ['Four original-product regression failures were reproduced; candidate tests were skipped by the parser failure.',
            'This is correctness evidence, not latency or UI performance evidence.']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=['windows', 'apple', 'layout_first', 'wrap_import', 'layout_third', 'navigation'])
    parser.add_argument('root', type=Path)
    parser.add_argument('--validator', type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    details = navigation(root, args.validator) if args.case == 'navigation' else globals()[args.case](root)
    summary = {'schemaVersion': 1, 'analysisKind': 'Post-download analysis; original ZIP members verified without modification',
        **verify_zip(root), **details, 'declaredScopeComplete': False}
    summary['jobUrl'] = f"https://github.com/yom-chadash/otzaria/actions/runs/{summary['runId']}/job/{summary['jobId']}"
    log = root / 'workflow-job.log'
    if log.exists():
        data = log.read_bytes()
        summary['jobLogSha256'] = sha(log)
        summary['jobLogBytes'] = len(data)
        summary['jobLogOrigin'] = 'GitHub connector decoded job log; not an original Actions log ZIP'
        summary['jobLogNewlineTransformation'] = 'none; connector text already LF'
        assert b'\r' not in data
    payload = (json.dumps(summary, indent=2, ensure_ascii=False) + '\n').encode()
    output = root / 'analysis-summary.json'
    if output.exists():
        assert output.read_bytes() == payload, 'Refusing to overwrite a different frozen summary'
    else:
        output.write_bytes(payload)
    print(json.dumps({'summary': str(output), 'sha256': sha(output), 'classification': summary['classification']}))


if __name__ == '__main__':
    main()
