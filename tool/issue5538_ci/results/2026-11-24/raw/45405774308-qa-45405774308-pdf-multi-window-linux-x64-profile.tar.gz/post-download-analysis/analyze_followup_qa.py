"""Post-download correctness summaries; never executes the application."""
import hashlib
import json
from pathlib import Path
import zipfile

BASE = Path('/workspace/scratch/8fd497e5cf89/pdf-5538-ci-evidence')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def single(root, name):
    paths = list(root.rglob(name))
    assert len(paths) == 1, (root, name, paths)
    return paths[0]


def start(root):
    receipt = read(root / 'artifact-receipt.json')
    archive = root / 'artifact.zip'
    assert digest(archive) == receipt['sha256']
    assert archive.stat().st_size == receipt['size']
    members = []
    with zipfile.ZipFile(archive) as bundle:
        for item in bundle.infolist():
            if item.is_dir():
                continue
            data = bundle.read(item)
            assert (root / item.filename).read_bytes() == data
            members.append({'path': item.filename, 'bytes': len(data),
                            'sha256': hashlib.sha256(data).hexdigest()})
    return {
        'schemaVersion': 1,
        'analysisKind': 'post-download correctness analysis; original artifact members are unchanged',
        'runId': receipt['run'], 'jobId': receipt['job'], 'artifactId': receipt['artifact'],
        'jobUrl': f"https://github.com/yom-chadash/otzaria/actions/runs/{receipt['run']}/job/{receipt['job']}",
        'sourceCommit': receipt['source'], 'artifactZipSha256': receipt['sha256'],
        'artifactZipBytes': receipt['size'], 'performanceComparison': False,
        'rawEvidence': members,
    }


def finish(root, summary):
    output = root / 'analysis-summary.json'
    assert not output.exists(), output
    output.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({'group': root.name, 'sha256': digest(output),
                      'classification': summary['classification']}))


def multi_window(root, summary):
    verified, host = read(single(root, 'verified.json')), read(single(root, 'host.json'))
    assert verified['status'] == 'passed' and verified['exitCode'] == 0
    assert verified['sourceSha'] == host['sourceSha'] == summary['sourceCommit']
    assert host['flutter']['frameworkVersion'] == '3.47.7'
    assert verified['engineIdentity'] == host['engineIdentity']
    assert verified['bundleManifestSha256'] == host['bundleIdentity']['manifestSha256']
    assert verified['aotPayload'] == host['bundleIdentity']['aotPayload']
    states = host['source']
    assert states['beforeBuild'] == states['afterBuild'] == states['afterRun']
    assert states['beforeBuild']['clean'] is True
    report_path = single(root, 'report.json')
    report, completion = read(report_path), read(single(root, 'completion.json'))
    assert digest(report_path) == completion['reportSha256'] == verified['reportSha256']
    assert completion['status'] == 'passed' and completion['error'] is None
    assert completion['unhandledErrors'] == []
    assert completion['sourceSha'] == summary['sourceCommit']
    assert completion['engineIdentity'] == verified['engineIdentity']
    assert completion['bindingClass'] == 'WidgetsFlutterBinding'
    assert completion['nativePlatformDispatcher'] is True
    assert report['status'] == 'passed' and report['realPlatformDispatcher'] is True
    expected = ['open', 'concurrentWork', 'minimizeRestore', 'closeSecondary', 'reopen', 'closeReopened', 'teardown']
    assert list(report['steps']) == expected
    assert all(step['status'] == 'passed' for step in report['steps'].values())
    opening = report['steps']['open']
    assert opening['primary']['viewId'] != opening['secondary']['viewId']
    assert opening['primary']['nativeHandle'] != opening['secondary']['nativeHandle']
    teardown = report['steps']['teardown']
    assert all(teardown[key] == 0 for key in ('ownedWindowsRemaining', 'ownedDocumentsRemaining', 'pendingOperations'))
    assert teardown['indexingActive'] is False
    summary.update(classification='completed-app-correctness', declaredScopeComplete=True,
                   jobConclusion='success', platform=host['platform'], buildMode=host['buildMode'],
                   flutter=host['flutter'], sourceUnchanged=True, engineRevision=host['engineRevision'],
                   engineIdentity=verified['engineIdentity'], bundleManifestSha256=verified['bundleManifestSha256'],
                   aotPayload=verified['aotPayload'], reportSha256=verified['reportSha256'], processExitCode=0,
                   independentAppLaunches=1, rawScenarioReportRetained=True, postDownloadScenarioContractRevalidation=True,
                   passedSteps=expected, separateNativeWindowsVerified=True, teardown=teardown, fixture=report['fixture'])
    summary['limitations'] = [
        'Functional correctness, one owned process on this host; no frame-time, CPU, memory or performance improvement claim.',
        'The fixture has four generated vector pages; this is not the real-book paired measurement campaign.',
        'Overlapping submissions do not demonstrate native parallel execution; no physical printer or physical sleep.',
        'Visible readiness uses the rendered layer tree, not GPU presentation time.',
    ]


def installed(root, summary):
    report_path = single(root, 'installed-plugin-report.json')
    report = read(report_path)
    assert report['status'] == 'passed' and report['frameworkPassed'] is True
    assert report['commit'] == summary['sourceCommit']
    assert all(report[key] == [] for key in ('errors', 'contractErrors', 'testFailures'))
    assert report['flutterVersion'] == '3.47.7'
    pdf = report['pdfRuntime']
    assert pdf['status'] == 'passed' and pdf['bundlePathsVerified'] is True
    assert pdf['ownedDocumentsRemaining'] == pdf['ownedTabsRemaining'] == 0
    assert pdf['indexingActiveAfter'] is False
    assert len(pdf['steps']) == 8 and all(x['status'] == 'passed' for x in pdf['steps'].values())
    cycles = pdf['steps']['repeatedLifecycle']
    assert cycles['requiredCycles'] == cycles['completedCycles'] == len(cycles['cycles']) == 50
    assert all(c['nativeCloseCompleted'] and c['ownedTabsRemaining'] == 0 and c['raster']['contentPixelsVerified'] for c in cycles['cycles'])
    wrapper_paths = list(root.glob('**/host/*/report.json'))
    assert len(wrapper_paths) == 1
    assert read(wrapper_paths[0])['installedPluginProbe'] == report
    summary.update(classification='completed-app-correctness', declaredScopeComplete=True,
                   jobConclusion='success', platform=report['platform'], buildMode=report['buildMode'],
                   flutterVersion=report['flutterVersion'], dartVersion=report['dartVersion'],
                   independentAppLaunches=1, pdfSteps=list(pdf['steps']),
                   completedOpenRenderCloseCycles=50, verifiedNativeCloses=50,
                   fixture=pdf['fixture'], reportSha256=digest(report_path),
                   hostReportSha256=digest(wrapper_paths[0]), loadedModules=pdf['steps']['loadedModules'],
                   teardown={key: pdf[key] for key in ('ownedDocumentsRemaining', 'ownedTabsRemaining', 'indexingActiveAfter')})
    architecture_paths = list(root.glob('pdf-architecture.json'))
    if architecture_paths:
        architecture = read(architecture_paths[0])
        assert architecture['status'] == 'passed' and architecture['commit'] == summary['sourceCommit']
        assert architecture['reportSha256'] == digest(wrapper_paths[0])
        summary['verifiedArchitecture'] = architecture['architecture']
        summary['nativeModules'] = architecture['modules']
    summary['limitations'] = [
        'General WebView/installed-app QA and PDF functional checks; recorded phase timings are not an A/B performance study.',
        'Fifty reopen cycles occur inside one process and are not fifty independent launches.',
        'Four generated PDF pages; no physical printer, physical sleep, or physical mobile-device acceptance.',
        'The installed-app desktop lifecycle uses tabs; actual OS windows have a separate artifact.',
    ]


def product(root, summary, platform):
    assert (root / 'pdf-product-source.txt').read_text(encoding='utf-8-sig').strip() == summary['sourceCommit']
    summary['flutter'] = read(root / 'pdf-product-sdk.json')
    assert summary['flutter']['frameworkVersion'] == '3.47.7'
    summary['platform'] = platform
    events = [json.loads(line) for line in (root / 'pdf-product-tests.json').read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    tests = [e for e in events if e['type'] == 'testDone' and not e.get('hidden', False)]
    assert len(tests) == 93 and all(t['result'] == 'success' and not t['skipped'] for t in tests)
    assert [e for e in events if e['type'] == 'done'] == [events[-1]] and events[-1]['success'] is True
    assert not [e for e in events if e['type'] == 'error']
    assert 'No issues found!' in (root / 'pdf-product-analyze.log').read_text(encoding='utf-8-sig')
    summary.update(classification='completed-product-regression-checks', declaredScopeComplete=True,
                   jobConclusion='success', fullFlutterAnalyze='passed', testsPassed=93, testsFailed=0,
                   testsSkipped=0, hiddenFixtureLifecycleEvents=sum(e['type'] == 'testDone' and e.get('hidden', False) for e in events),
                   jsonlRows=len(events), testReportFormat='JSON Lines in a .json-named file',
                   suites=[e['suite']['path'] for e in events if e['type'] == 'suite'])
    summary['limitations'] = [
        'Static analysis and correctness regressions do not measure product performance.',
        'Fixture lifecycle events marked hidden are reported separately, not counted as additional tests.',
        'These results belong to the exact QA source SHA in this summary.',
    ]


if __name__ == '__main__':
    import sys
    assert len(sys.argv) > 1, 'Pass explicit downloaded group directories'
    for argument in sys.argv[1:]:
        root = Path(argument).resolve()
        summary = start(root)
        name = read(root / 'artifact-receipt.json')['name']
        if name.startswith('pdf-multi-window-'):
            multi_window(root, summary)
        elif name.startswith('installed-plugin-') or name == 'apple-webview-macos-profile':
            installed(root, summary)
        elif name.startswith('pdf-5538-product-validation-'):
            product(root, summary, name.rsplit('-', 1)[-1])
        else:
            raise ValueError(f'Unknown artifact scope {name}')
        finish(root, summary)


