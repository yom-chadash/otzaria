"""Verify isolated Apple source/binary receipts and summarize each host separately."""
import argparse
import importlib.util
import json
import math
from pathlib import Path
from statistics import median

from analyze_followup_failures import read, sha, verify_zip

SOURCE = '9b5e7b2fde53fe6ad0408940ece653ff8d0c49e4'
UPSTREAM = '683df93e986af19bbcefd22606a417083116847b'
FRAMEWORK = 'ab2912035e160d9cad6306df307576da6128ebdb'
ENGINE = '371f77202a73e8dff57a8b3bff75bca55c090aee'
ORDER = ['pdfium', 'coregraphics', 'coregraphics', 'pdfium']
METRICS = ['openUs', 'firstRasterUs', 'imageReadyUs', 'imageReadyFrameSubmittedUs']


def stats(values):
    ordered = sorted(values)
    return {'n': len(values), 'p50': median(values), 'p95NearestRank': ordered[math.ceil(len(values) * .95) - 1],
            'min': ordered[0], 'max': ordered[-1]} if values else None


def provenance(path):
    p = read(path)
    assert p['sourceCommit'] == SOURCE and p['sourceDirty'] is False
    assert p['upstreamCommit'] == UPSTREAM
    assert p['flutter']['frameworkVersion'] == '3.50.0'
    assert p['flutter']['frameworkRevision'] == FRAMEWORK and p['flutter']['engineRevision'] == ENGINE
    assert p['architecture'] == 'x86_64' and p['productionSdkChanged'] is False
    assert p['otzariaPerformanceComparison'] is False
    compatibility = p['compileCompatibility']
    import hashlib
    assert hashlib.sha256(compatibility['patch'].encode()).hexdigest() == compatibility['patchSha256']
    assert compatibility['changedMethods'] == ['createNewDocument', 'createDocumentFromJpegData']
    assert compatibility['renderTextSchedulerChanged'] is False
    assert p['runOrder'] == ORDER
    return p


def prepared_identity(root):
    p = provenance(root / 'provenance.json')
    prepared, consumer = read(root / 'prepared-receipt.json'), read(root / 'consumer.json')
    assert prepared['provenanceSha256'] == sha(root / 'provenance.json')
    assert prepared['sourceCommit'] == consumer['sourceCommit'] == SOURCE
    assert prepared['upstreamCommit'] == UPSTREAM and prepared['flutterRevision'] == FRAMEWORK
    assert prepared['flutterEngineRevision'] == ENGINE
    assert prepared['architecture'] == consumer['architecture'] == 'x86_64'
    assert prepared['macOSVersion'] == consumer['macOSVersion']
    assert prepared['executableSha256'] == consumer['executableSha256']
    assert prepared['measurementProcesses'] == 0 and prepared['expectedBaselineProcesses'] == 36
    assert consumer['transportSha256'] == sha(root / 'prepared-receipt.json')
    assert consumer['timingsPooledAcrossHosts'] is False
    inventory = prepared['bundleInventory']
    files = {name.removeprefix(prepared['bundleName'] + '/'): value['sha256']
             for name, value in inventory.items() if value['kind'] == 'file'}
    assert files == p['bundleFiles']
    return p, prepared, consumer


def validate_report(report, config):
    assert report['measurementComplete'] is True and report['errors'] == []
    assert all(report[k] == config[k] for k in ['backend', 'workload', 'inputSha256'])
    count = 20 if report['workload'] == 'lifecycle' else 3
    assert len(report['observations']) == report['documentsOpened'] == report['documentsClosed'] == count
    assert report['mode'] == 'flutter-release' and report['physicalDevice'] is False
    assert report['nativeHandleCompatibilityProven'] is False
    assert report['boundaryCheckpointsOutsideTimedOperations'] is True
    assert report['frameTimings']
    for i, row in enumerate(report['observations']):
        assert row['iteration'] == i and row['warmup'] is (i == 0)
        assert row['physicalDisplayLatencyMeasured'] is False and row['nativeCanceledPixelCountMeasured'] is False
        assert 0 < row['openUs'] <= row['firstRasterUs'] <= row['imageReadyUs'] <= row['imageReadyFrameSubmittedUs']
        assert row['pixelWidth'] > 0 and row['pixelHeight'] > 0 and row['pageCount'] > 0
        if report['workload'] == 'lifecycle':
            assert row['queuedCompletions'] == []
        else:
            assert len(row['queuedCompletions']) == min(row['pageCount'], 10)
        if report['workload'] == 'custom':
            assert row['customReadBytes'] > 0 and row['customReadCalls'] > 0
    if report['workload'] == 'custom':
        assert report['customDisposeCallbacks'] == count


def baseline(root):
    p, prepared, consumer = prepared_identity(root)
    summary, runs = read(root / 'summary.json'), read(root / 'runs.json')
    assert summary['runs'] == runs and len(runs) == 4
    assert summary['measurementComplete'] is True and summary['binaryVerifiedAfterBlock'] is True
    assert summary['sameHost'] is True and summary['timingsPooledAcrossHosts'] is False
    assert summary['runOrder'] == ORDER and summary['transportSha256'] == consumer['transportSha256']
    # phase-progress is a pre-launch checkpoint; summary/runs are terminal.
    checkpoint = read(root / 'phase-progress.json')
    assert checkpoint['phase'] == 'launching' and checkpoint['label'] == runs[-1]['label']
    assert checkpoint['completedProcesses'] == 3 and checkpoint['expectedProcesses'] == 4
    document = next(d for d in prepared['documents'] if d['id'] == summary['document'])
    observations_per_process = 20 if summary['workload'] == 'lifecycle' else 3
    rows, raw_by_backend = [], {'pdfium': [], 'coregraphics': []}
    for index, run in enumerate(runs):
        label = run['label']
        report_path = root / (label + '.json')
        report, config = read(report_path), read(root / (label + '-config.json'))
        process = read(root / (label + '.process.json'))
        assert sha(report_path) == run['reportSha256']
        assert report['backend'] == ORDER[index] and report['workload'] == summary['workload']
        assert report['inputSha256'] == document['sha256'] and report['inputBytes'] == document['sizeBytes']
        assert not report['phaseDiagnostics']
        validate_report(report, config)
        assert process['commandCompleted'] and not process['timedOut'] and process['ownedProcessGroupReaped']
        assert process['exitCode'] == 0
        measured = [r for r in report['observations'] if not r['warmup']]
        assert len(measured) == observations_per_process - 1
        raw_by_backend[report['backend']].extend(report['observations'])
        queued = [q for r in measured for q in r['queuedCompletions']]
        rows.append({'label': label, 'backend': report['backend'], 'reportSha256': run['reportSha256'],
            'processGroupPid': process['processGroupPid'], 'measuredObservations': len(measured), 'warmupObservations': 1,
            'operationMediansUs': {k: median(r[k] for r in measured) for k in METRICS},
            'processPeakRssBytes': run['processPeakRssBytes'], 'wholeProcessSecondsIncludingStartupAndWarmup': run['processSeconds'],
            'rssBefore': report['rssBefore'], 'rssAfter': report['rssAfter'],
            'documentsOpened': report['documentsOpened'], 'documentsClosed': report['documentsClosed'],
            'customDisposeCallbacks': report['customDisposeCallbacks'],
            'customReadBytesPerObservation': [r['customReadBytes'] for r in measured],
            'customReadCallsPerObservation': [r['customReadCalls'] for r in measured],
            'cancellationObservations': {'requests': len(queued),
                'cancelRequested': sum(q['cancelRequested'] for q in queued),
                'cancelRequestedAndReturnedImage': sum(q['cancelRequested'] and q['returnedImage'] for q in queued),
                'nonCancelledReturnedImage': sum(not q['cancelRequested'] and q['returnedImage'] for q in queued),
                'nativePixelsRenderedForCancelledWorkMeasured': False},
            'wholeProcessFrameSamplesIncludingWarmup': {k: stats([f[k] for f in report['frameTimings']])
                                                      for k in ['buildUs', 'rasterUs', 'totalUs']},
            'wholeProcessUiTimerGapsUsIncludingWarmup': stats(report['uiTimerGapsUs'])})
    comparisons = {}
    for metric in METRICS:
        a = [r['operationMediansUs'][metric] for r in rows if r['backend'] == 'pdfium']
        b = [r['operationMediansUs'][metric] for r in rows if r['backend'] == 'coregraphics']
        comparisons[metric] = {'pdfiumProcessMedians': a, 'coregraphicsProcessMedians': b,
            'pdfiumMedianOfProcessMedians': median(a), 'coregraphicsMedianOfProcessMedians': median(b),
            'coregraphicsRelativePercent': 100 * (median(b) / median(a) - 1),
            'orderedPairEffectsPercent': [100 * (rows[j]['operationMediansUs'][metric] /
                                                     rows[i]['operationMediansUs'][metric] - 1)
                                          for i, j in [(0, 1), (3, 2)]]}
    parity = {}
    for backend, values in raw_by_backend.items():
        parity[backend] = {key: sorted({v[key] for v in values}) for key in
                          ['pixelSha256', 'textSha256', 'textCharacters', 'hebrewCharacters',
                           'pageCount', 'pixelWidth', 'pixelHeight', 'linkCount']}
    return {'classification': 'completed-measurement', 'kind': 'unprofiled-isolated-upstream-ABBA',
        'document': summary['document'], 'workload': summary['workload'], 'transportSha256': consumer['transportSha256'],
        'executableSha256': prepared['executableSha256'], 'macOSVersion': consumer['macOSVersion'],
        'runOrder': ORDER, 'independentProcessesPerBackend': 2, 'totalProcesses': 4,
        'totalObservationsIncludingWarmup': 4 * observations_per_process,
        'measuredObservationsPerProcess': observations_per_process - 1,
        'sameHostBlock': True, 'timingsPooledAcrossHosts': False, 'processes': rows,
        'comparisonOfProcessMedians': comparisons, 'observedOutputSignatures': parity,
        'crossBackendTextHashEqual': parity['pdfium']['textSha256'] == parity['coregraphics']['textSha256'],
        'crossBackendPixelHashEqual': parity['pdfium']['pixelSha256'] == parity['coregraphics']['pixelSha256'],
        'sdk': p['flutter'], 'compileCompatibility': p['compileCompatibility'],
        'limitations': ['One ABBA block on one hosted Intel Mac per document/workload; two processes per backend are not broad performance assurance.',
            'The first observation in each process is excluded from operation medians. Remaining observations within that process are dependent.',
            'firstRasterUs, imageReadyUs and imageReadyFrameSubmittedUs are cumulative from open, not isolated render/paint durations.',
            'The frame-submitted endpoint follows endOfFrame and does not measure physical display presentation.',
            'Text/raster signatures are recorded independently. Different backend output is not accepted as equivalent rendering or Hebrew extraction.',
            'Queued cancellation reports whether an image returned, not whether native rendering/pixel work occurred before cancellation.',
            'Frame/timer/RSS values describe this small harness including warmup and startup; they are not Otzaria reader jank or leak acceptance.',
            'Both backends use one experimental Flutter 3.50 binary. No Otzaria SDK, package or native-handle adoption is established.']}


def trace(root, harness):
    p, prepared, consumer = prepared_identity(root)
    raw = read(root / 'traces/summary.json')
    final = read(root / 'trace-binary-verification.json')
    assert raw['complete'] and raw['sourceCommit'] == SOURCE and raw['workloadsComplete']
    assert raw['baselineProvenanceSha256'] == sha(root / 'provenance.json')
    assert raw['executableSha256'] == prepared['executableSha256']
    assert final['bundleVerifiedAfterTrace'] and not final['baselineTimingEvidence']
    assert final['transportSha256'] == consumer['transportSha256']
    assert not raw['baselineTimingsProfiled'] and not raw['timingsComparableWithBaseline']
    parser_path = harness / 'internal_apple_trace.py'
    assert sha(parser_path) == p['harnessFiles'][parser_path.name]
    spec = importlib.util.spec_from_file_location('frozen_apple_parser', parser_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    exports = []
    for run in raw['traceRuns']:
        label = run['corpus'] + '-' + run['backend']
        report_path = root / 'traces' / (label + '-report.json')
        report = read(report_path)
        assert sha(report_path) == run['reportSha256'] and run['workloadComplete'] and run['workloadError'] is None
        validate_report(report, read(root / 'traces' / (label + '-config.json')))
        assert report['phaseDiagnostics'] is True
        for export in run['exports']:
            path = root / 'traces' / export['path']
            assert sha(path) == export['sha256']
            reproduced = module.native_threads(path, 'issue5538_apple', run['backend'])
            assert reproduced == {k: v for k, v in export.items() if k not in ['path', 'sha256']}
            exports.append({'document': run['corpus'], 'backend': run['backend'], **export})
    assert any(row['threadSamples'] for row in exports)
    containers = [path for path in (root / 'traces').rglob('*') if path.is_file()
                  and any(part.endswith('.trace') for part in path.parts)]
    return {'classification': 'completed-measurement', 'kind': 'isolated-upstream-native-thread-diagnostic',
        'executableSha256': prepared['executableSha256'], 'transportSha256': consumer['transportSha256'],
        'sdk': p['flutter'], 'declaredDocuments': raw['declaredDocuments'], 'declaredBackends': raw['declaredBackends'],
        'workloadProcesses': len(raw['traceRuns']), 'observationsPerProcessIncludingWarmup': 3,
        'xctraceVersion': raw['xctraceVersion'], 'workloadsComplete': True, 'exports': exports,
        'nativeTraceFiles': len(containers), 'nativeTraceBytes': sum(path.stat().st_size for path in containers),
        'baselineTimingEvidence': False, 'processAttribution': raw['processAttribution'],
        'compileCompatibility': p['compileCompatibility'],
        'limitations': ['Sampled stacks are attributed by executable name; exported PIDs are retained but not independently matched to a launch-PID receipt.',
            'Native symbol samples count stack rows containing a backend symbol; multiple symbols can occur in one sample.',
            'Unidentifiable rows and exports without resolved thread/backtrace remain explicit. No symbol sample is not proof of no native work.',
            'Overlapping xctrace schemas are retained separately and their samples are not added into an independent sample count.',
            'Profiler and phase-progress I/O are enabled only for this diagnostic; its times are not ABBA performance measurements.',
            'One captured workload does not establish that all backend operations always use the same thread.',
            'This is isolated upstream Flutter 3.50 on a hosted Intel Mac, with no product UI equivalence or adoption claim.']}


def preparation(root):
    p = provenance(root / 'build/provenance.json')
    result = read(root / 'prepared-summary.json')
    context = read(root / 'build/prepared-context.json')
    assert result['preparedComplete'] is True and result['measurementProcesses'] == 0
    assert result['measurementComplete'] is False and context['measurementProcesses'] == 0
    assert context['provenanceSha256'] == sha(root / 'build/provenance.json')
    process_receipts = sorted((root / 'build').glob('*.process.json'))
    for path in process_receipts:
        item = read(path)
        assert item['commandCompleted'] and item['exitCode'] == 0 and not item['timedOut'] and item['ownedProcessGroupReaped']
    return {'classification': 'environment-preflight', 'kind': 'prepared-experimental-binary-only',
        **result, 'sdk': p['flutter'], 'compileCompatibility': p['compileCompatibility'],
        'provenanceSha256': sha(root / 'build/provenance.json'), 'completedPreparationCommands': len(process_receipts),
        'expectedBaselineProcesses': 36, 'limitations': ['Build/preparation receipts contain no completed performance observations.',
            'The runtime bundle is transported separately between CI jobs and is not embedded in the permanent evidence archive.']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('kind', choices=['preparation', 'baseline', 'trace'])
    parser.add_argument('root', type=Path)
    parser.add_argument('--harness', type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    root = args.root.resolve()
    archive = verify_zip(root)
    receipt = read(root / 'artifact-receipt.json')
    if args.kind == 'trace':
        result = trace(root, args.harness)
    else:
        result = {'preparation': preparation, 'baseline': baseline}[args.kind](root)
    result = {'schemaVersion': 1, 'section': 'E12', 'runId': receipt['runId'], 'jobId': receipt['jobId'],
        'artifactId': receipt['artifactId'], 'sourceCommit': SOURCE, 'upstreamCommit': UPSTREAM,
        **archive, **result, 'otzariaAdoptionApproved': False, 'productionSdkChanged': False,
        'physicalDeviceAcceptance': False, 'analysisScriptSha256': sha(Path(__file__))}
    data = (json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode()
    path = root / 'analysis-summary.json'
    assert not path.exists() or path.read_bytes() == data, 'Refusing to alter a frozen summary'
    if not path.exists():
        with path.open('xb') as stream:
            stream.write(data)
    print(json.dumps({'path': str(path), 'bytes': len(data), 'sha256': sha(path), 'kind': result['kind']}))


if __name__ == '__main__':
    main()
