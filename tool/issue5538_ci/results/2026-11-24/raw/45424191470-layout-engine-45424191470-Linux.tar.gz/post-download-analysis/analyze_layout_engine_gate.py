"""Verify the three hosted compatibility gates after the test-spy correction."""

import json
from pathlib import Path
import sys

from analyze_post_implementation import read, sha, start, test_counts


SOURCE = "cdea38083d06b445b4ec67d8345109a0457924af"
RUN = 45424191470
JOBS = {"Linux": 138551564377, "Windows": 138551564634, "macOS": 138551563962}


def analyze(root):
    summary = start(root)
    platform = root.name.rsplit("-", 1)[-1]
    assert summary["runId"] == RUN and summary["jobId"] == JOBS[platform]
    assert (root / "pdf-layout-engine-source.txt").read_text(encoding="utf-8-sig").strip() == SOURCE
    sdk = read(root / "pdf-layout-engine-sdk.json")
    assert sdk["frameworkVersion"] == "3.47.7"
    assert sdk["dartSdkVersion"].startswith("3.13.5")
    assert "No issues found!" in (root / "pdf-layout-engine-analyze.log").read_text(encoding="utf-8-sig")
    engine = test_counts(root / "pdf-layout-engine-tests.jsonl")
    viewer = test_counts(root / "pdf-layout-engine-viewer-tests.jsonl")
    assert engine["passed"] == 118 and viewer["passed"] == 112
    summary.update(
        classification="completed-product-regression-checks",
        declaredScopeComplete=True,
        jobConclusion="success",
        testedSourceCommit=SOURCE,
        scope="Compatible S02 engine and M02 immutable-layout viewer, including the corrected preparation spy",
        platform=platform,
        sdk=sdk,
        staticAnalysis="passed",
        engineTests=engine,
        viewerTests=viewer,
        performanceMeasurement=False,
        productPerformanceClaim=False,
        limitations=[
            "These gates prove hosted static-analysis and regression-test outcomes on the exact source; they are not performance measurements.",
            "The 118 engine and 112 viewer tests all completed without failures or skips on each platform.",
            "The macOS lane ran on hosted Intel hardware; this does not establish ARM64 or physical mobile coverage.",
            "The previous test-spy failures remain separate immutable evidence; they have not been rewritten as successes.",
        ],
    )
    return summary


def main():
    for argument in sys.argv[1:]:
        root = Path(argument).resolve()
        summary = analyze(root)
        output = root / "analysis-summary.json"
        assert not output.exists(), "Refusing to replace a frozen annotation"
        output.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
        print(json.dumps({"folder": root.name, "summarySha256": sha(output),
                          "enginePassed": summary["engineTests"]["passed"],
                          "viewerPassed": summary["viewerTests"]["passed"],
                          "originalMembersVerified": summary["verifiedOriginalMembers"]}))


if __name__ == "__main__":
    main()
