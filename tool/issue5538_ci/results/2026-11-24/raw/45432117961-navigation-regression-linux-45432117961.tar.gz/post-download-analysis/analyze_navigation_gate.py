"""Post-download checks of exact CI bytes; never writes original members."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/8fd497e5cf89')
VALIDATOR = ROOT / 'pdf5538-navigation-gate-payload-v2/files/tool/issue5538_ci/navigation_regression_gate.py'
VALIDATOR_SHA = '972da42cc2f66866bdde1c2b0a4b8c1b35ef363b3b709084f19f35d234b9fe3d'
BASE = 'cdea38083d06b445b4ec67d8345109a0457924af'
CANDIDATE = '4f7d95e3d9e7d932a3675d837bfa3f8e7f3be703'
PRODUCT = 'packages/pdfrx/lib/src/widgets/pdf_viewer.dart'
TEST = 'packages/pdfrx/test/pdf_viewer_test.dart'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def analyze(root):
    assert digest(VALIDATOR) == VALIDATOR_SHA
    spec = importlib.util.spec_from_file_location('navigation_gate_reviewed', VALIDATOR)
    validator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    receipt = json.loads((root / 'artifact-receipt.json').read_text())
    assert digest(root / 'artifact.zip') == receipt['sha256']
    assert (root / 'artifact.zip').stat().st_size == receipt['bytes']
    for member in receipt['members']:
        path = root / member['path']
        assert path.stat().st_size == member['bytes'] and digest(path) == member['sha256']
    prepared = json.loads((root / 'prepared-sources.json').read_text())
    baseline = prepared['baselineOriginal']
    overlay = prepared['baselineWithIdenticalTestOverlay']
    candidate = prepared['candidate']
    assert baseline['commit'] == overlay['commit'] == BASE
    assert candidate['commit'] == CANDIDATE
    assert set(baseline['files']) == set(overlay['files']) == set(candidate['files'])
    assert {p for p in baseline['files'] if baseline['files'][p] != candidate['files'][p]} == {PRODUCT, TEST}
    assert {p for p in baseline['files'] if baseline['files'][p] != overlay['files'][p]} == {TEST}
    assert candidate['files'][TEST] == overlay['files'][TEST]
    assert prepared['identicalTestSha256'] == candidate['files'][TEST]['sha256']
    assert candidate['files'][PRODUCT]['sha256'] == '1b4bc0a7cf375fe3eac309af1cbc2a847dd238215313f14ba178a73315dbb2b9'
    assert prepared['reviewedPatchSha256'] == digest(root / 'reviewed-product-and-tests.patch')
    before = json.loads((root / 'before-tests.json').read_text())
    after = json.loads((root / 'after-tests.json').read_text())
    assert before == after and before['sourcesVerified'] and before['sdkVerified']
    lock = digest(root / 'shared-pubspec.lock')
    assert all(r['pubspec.lock'] == lock for r in before['resolvedDependencies'].values())
    sdk_before = json.loads((root / 'flutter-before.json').read_text())
    sdk_after = json.loads((root / 'flutter-after.json').read_text())
    assert sdk_before == sdk_after == prepared['sdk']
    assert sdk_before['frameworkVersion'] == '3.47.7'
    assert sdk_before['frameworkRevision'] == 'abaf9c523780a608bd46686fd5e53740a07077f8'
    assert sdk_before['engineRevision'] == 'deb287481e3ce9468f3434937ced4240a70539ca'
    assert sdk_before['dartSdkVersion'] == '3.13.5'
    assert 'No issues found!' in (root / 'candidate-analyze.log').read_text()
    results = {}
    for role in ['baseline', 'candidate']:
        result = validator.validate_report(root / f'{role}-tests.jsonl', int((root / f'{role}-exit.txt').read_text()), role == 'baseline')
        assert result == json.loads((root / f'{role}-validated.json').read_text())
        results[role] = result
    records = [json.loads(line) for line in (root / 'candidate-tests.jsonl').read_text().splitlines() if line.strip()]
    suite_paths = {r['suite']['id']: r['suite']['path'] for r in records if r.get('type') == 'suite'}
    starts = {r['test']['id']: r['test'] for r in records if r.get('type') == 'testStart'}
    suites = {}
    skipped = 0
    for row in records:
        if row.get('type') != 'testDone' or row.get('hidden', False):
            continue
        skipped += int(row.get('skipped', False))
        suite = suite_paths[starts[row['testID']]['suiteID']].replace('\\', '/').split('/test/')[-1]
        suites[suite] = suites.get(suite, 0) + 1
    assert skipped == 0 and sum(suites.values()) == results['candidate']['visibleTests'] == 123
    regressions = [row['name'] for row in results['candidate']['cases'] if row['name'].startswith('navigation ')]
    summary = {
        'schemaVersion': 1, 'classification': 'baseline-regression-reproduced-candidate-correctness-passed',
        'declaredScopeComplete': True, 'runId': receipt['run'], 'jobId': receipt['job'], 'artifactId': receipt['artifact'],
        'workflowSourceCommit': receipt['source'], 'platform': root.name.split('-')[2],
        'artifact': {'bytes': receipt['bytes'], 'sha256': receipt['sha256'], 'originalMembers': receipt['verifiedOriginalMembers']},
        'sources': {'baselineCommit': BASE, 'candidateCommit': CANDIDATE, 'baselineTree': baseline['tree'], 'candidateTree': candidate['tree'],
                    'reviewedProductSha256': candidate['files'][PRODUCT]['sha256'], 'identicalTestsSha256': prepared['identicalTestSha256'],
                    'baselineOverlayOnly': TEST, 'trackedSourceFilesVerified': len(candidate['files']), 'sharedLockSha256': lock,
                    'sourceSdkDependenciesUnchangedAfterTests': True},
        'sdk': {key: sdk_before[key] for key in ['frameworkVersion', 'frameworkRevision', 'engineRevision', 'dartSdkVersion']},
        'baseline': {'cases': results['baseline']['cases'], 'expectedProductFailures': 4, 'unrelatedErrors': 0,
                     'reportSha256': results['baseline']['reportSha256'], 'failureReason': validator.EXPECTED_REASON},
        'candidate': {'passed': 123, 'failed': 0, 'skipped': 0, 'suiteCounts': suites, 'navigationRegressionsPassed': len(regressions),
                      'navigationCases': regressions, 'reportSha256': results['candidate']['reportSha256'], 'analyze': 'passed'},
        'analysis': {'origin': 'derived after download from verified original ZIP members', 'validatorSha256': VALIDATOR_SHA,
                     'checks': 'Revalidated both raw JSONL files with the reviewed validator; verified complete source snapshots, overlay, lock, SDK and per-suite counts.'},
        'conclusion': 'The original product reproduces the unresolved navigation Future in all four Legacy/Smart and matrix/page cases; the candidate preserves destination and completes all eleven navigation/lifecycle regressions plus existing selected viewer/layout tests.',
        'limitations': ['Correctness tests with controlled widget fixtures, not application performance or native PDF corpus measurements.',
                        'The geometry-change fix finishes the active animation at its requested destination before remapping; it does not preserve the original animation duration.',
                        'Other operating-system lanes and the native MG374 application diagnostic are separate evidence and are not implied by this result.'],
    }
    target = root / 'analysis-summary.json'
    assert not target.exists(), 'Do not overwrite a frozen summary'
    target.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'directory': str(root), 'summarySha256': digest(target), 'candidatePassed': 123, 'navigationPassed': len(regressions), 'suiteCounts': suites}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('directories', type=Path, nargs='+')
    for root in parser.parse_args().directories:
        analyze(root)
